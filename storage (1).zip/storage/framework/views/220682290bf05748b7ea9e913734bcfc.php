<?php $__env->startSection('title'); ?>
    فاتورة جديدة
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title'); ?>
    فاتورة جديدة
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_link'); ?>
    فاتورة المشتريات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title_link'); ?>
    فاتورة جديدة
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.messge_alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.messge_alert.fail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="card">

        

        <div class="card-body">
            <form action="<?php echo e(route('accounting.purchase_invoices.create_new_invoices')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <?php
                                    $month = date('m');
                                    $day = date('d');
                                    $year = date('Y');
                                    $today = $year . '-' . $month . '-' . $day;
                                    ?>
                                    <label for="">تاريخ الفاتورة</label>
                                    <input required type="date" name="bill_date" class="form-control text-center"
                                           value="<?php echo e($today); ?>">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="">تاريخ التسليم</label>
                                    <input required type="date" value="<?php echo e(date('Y-m-d')); ?>" name="due_date" class="form-control text-center">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="">الضريبة الاولى</label>
                                    <select name="tax_id" id="tax_id" class="form-control select2bs4">
                                        <option value="">اختر قيمة الضريبة ...</option>
                                        <?php $__currentLoopData = $taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key->id); ?>"><?php echo e($key->tax_name); ?> (<?php echo e($key->tax_ratio); ?>%)</option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="">المخزن</label>
                                    <select required class="form-control" name="wherehouse_id" id="wherehouse_id">
                                        <option value="">اختر مخزن</option>
                                        <?php $__currentLoopData = $wherehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key->id); ?>"><?php echo e($key->wherehouse_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>











                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="checkbox">التكرار</label>
                                    <input type="checkbox" id="checkbox" onchange="if_checked(this.value)">
                                </div>
                            </div>
                            <div style="display: none" id="recurring_form" class="col-md-12">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="">التكرار خلال</label>
                                            <input type="text" name="repeat_every" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="">خلال</label>
                                            <select class="form-control" name="repeat_type" id="">
                                                <option value="days">يوم</option>
                                                <option value="weeks">اسبوع</option>
                                                <option value="months">شهر</option>
                                                <option value="years">سنة</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="">الدورة</label>
                                            <input type="text" name="no_of_cycles" class="form-control" placeholder="الدورة">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 card bg-warning p-3">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">الرقم المرجعي للفاتورة</label>
                                    <input required name="invoice_reference_number" type="text" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">العميل</label>
                                    <select required class="form-control select2bs4" name="client_id" id="">
                                        <option value="">اختر عميل</option>
                                        <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key->id); ?>"><?php echo e($key->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">ملاحظات</label>
                                    <textarea class="form-control" name="note" id="" cols="30" rows="3"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-success">حفظ البيانات</button>
            </form>
        </div>

    </div>
    <div class="modal fade" id="modal-lg">
        <div class="modal-dialog modal-lg">
            <form action="<?php echo e(route('accounting.texes.create')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">اضافة ضريبة</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">اسم الضريبة</label>
                                    <input required type="text" class="form-control" name="tax_name"
                                        placeholder="اسم الضريبة">
                                </div>
                                <div class="form-group">
                                    <label for="">نسبة الضريبة</label>
                                    <input required type="text" class="form-control" name="tax_ratio"
                                        placeholder="اسم الضريبة">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">اغلاق</button>
                        <button type="submit" class="btn btn-primary">حفظ</button>
                    </div>

                </div>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.full.min.js')); ?>"></script>

    <script>
        
        
        

        
        

        
        

        
        
        
        
        
        
        
        


        function if_checked() {
            var checkbox = document.getElementById("checkbox");
            var recurring_form = document.getElementById("recurring_form");

            if (checkbox.checked == true) {
                recurring_form.style.display = "block";
            } else {
                recurring_form.style.display = "none";
            }
        }
    </script>

    <script>
        $(function() {
            $('.select2bs4').select2({
                theme: 'bootstrap4'
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/purchase_invoices/new_invoice/index.blade.php ENDPATH**/ ?>