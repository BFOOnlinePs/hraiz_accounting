<?php $__env->startSection('title'); ?>
    تصنيف المصروفات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title'); ?>
    تصنيف المصروفات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_link'); ?>
    الرئيسية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title_link'); ?>
    تصنيف المصروفات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.messge_alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.messge_alert.fail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-md-12">
            <button class="btn btn-dark" data-toggle="modal"
                    data-target="#expenses-category-create-modal">اضافة تصنيف للمصروف
            </button>
        </div>
    </div>
    <div class="row mt-2">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <table class="table table-hover table-bordered table-sm">
                        <thead>
                        <tr>
                            <th>الاسم</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if($data->isEmpty()): ?>
                            <tr>
                                <td colspan="2" class="text-center">لا توجد بيانات</td>
                            </tr>
                        <?php else: ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key->title); ?></td>
                                    <td>
                                        <button type="button" onclick="get_expenses_category_data(<?php echo e($key); ?>)"
                                                class="btn btn-success btn-sm"><span
                                                class="fa fa-edit"></span></button>


                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.accounting.expenses_category.modals.expensesCategoryCreate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.accounting.expenses_category.modals.expensesCategoryEdit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.full.min.js')); ?>"></script>

    <script>
        function get_expenses_category_data(data) {
            $('#expenses_category_id').val(data.id);
            $('#title').val(data.title);
            $('#expenses-category-edit-modal').modal('show');
        }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/expenses_category/index.blade.php ENDPATH**/ ?>