<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>قائمة الموردين</title>
    <style>

        @page{
            <?php if(!empty($system_setting)): ?>
background-image: url("<?php echo e(asset('storage/setting/'.$system_setting->letter_head_image)); ?>");
            <?php endif; ?> background-image-resize:6;
            margin-top:220px;
            margin-bottom:50px;
        }

        @page :first{
            <?php if(!empty($system_setting)): ?>
background-image: url("<?php echo e(asset('storage/setting/'.$system_setting->letter_head_image)); ?>");
            <?php endif; ?> background-image-resize:6;
            margin-bottom:50px;
            margin-top:220px;
        }
        .title{

        }
        table, td, th {
            border: 1px solid black;
        }

        table tr th {
            color: white;
        }
        .table{
            padding-top: 150px;
            border-collapse: collapse;
            width: 100%;
            text-align: center;
        }
        th{
            height: 70%;
        }
    </style>
</head>
<body>
<table class="table" cellpadding="10">
    <tr style="background-color: black;">
        <th>Supplier name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Orders</th>
    </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="text-align: left;width: 50%"><?php echo e($key->name); ?></td>
            <td style="text-align: left"><?php echo e($key->email); ?></td>
            <td style="text-align: left"><?php echo e($key->user_phone1); ?></td>
            <td><?php echo e($key->count); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/reports/supplier_report/index.blade.php ENDPATH**/ ?>