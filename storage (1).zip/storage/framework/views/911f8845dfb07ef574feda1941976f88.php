<table style="width: 100%" class="table table-sm table-bordered table-hover">
    <thead>
        <tr>
            <th style="width: 10px">#</th>
            <th style="width: 150px">معرف الطلبية</th>
            <th>المورد</th>
            <th style="width: 120px">تاريخ الطلبية</th>
            <th style="width: 120px">فواتير الطلبية</th>
            <th style="width: 350px"></th>
        </tr>
    </thead>
    <tbody>
        <?php if(!$data->isEmpty()): ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(($data ->currentpage()-1) * $data ->perpage() + $loop->index + 1); ?></td>
                    <td>
                        <a target="_blank" href="<?php echo e(route('procurement_officer.orders.anchor.index',['order_id'=>$key->order->id])); ?>"><?php echo e($key->order->reference_number); ?></a>
                    </td>
                    <td>
                        <?php echo e($key->user->name); ?>




                    </td>
                    <td>
                        <?php echo e($key->order->inserted_at); ?>

                    </td>
                    <td>
                        <?php if(App\Models\PurchaseInvoicesModel::where('order_id',$key->order->id)->get()->isEmpty()): ?>
                            لا يوجد
                        <?php else: ?>
                            <?php $__currentLoopData = App\Models\PurchaseInvoicesModel::where('order_id',$key->order->id)->where('client_id',$key->supplier_id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <a target="_blank" href="<?php echo e(route('accounting.purchase_invoices.invoice_view',['id'=>$child->id])); ?>"><?php echo e(date('d-m-Y',strtotime($child->created_at))); ?></a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </td>
                    <td>

                        <button onclick="get_order_id(<?php echo e($key->order->id); ?>,<?php echo e($key->user->id); ?>) " type="submit" class="btn btn-success btn-sm"><span class="fa fa-check"></span>&nbsp; انشاء فاتورة من الطلبية</button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr>
                <td colspan="6" class="text-center">لا توجد بيانات</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php echo e($data->links()); ?>


<script>
    function get_order_id(id,supplier_id){
        document.getElementById('order_input').value = id;
        document.getElementById('supplier_input').value = supplier_id;
    }
</script>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/purchase_invoices/ajax/search_order.blade.php ENDPATH**/ ?>