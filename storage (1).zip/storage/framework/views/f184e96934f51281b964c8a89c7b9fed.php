<table class="table table-sm table-striped- table-bordered table-hover">
    <thead>
        <tr>
            <th>رقم الشيك</th>
            <th>نوع الشيك</th>
            <th>اسم الزبون</th>
            <th>قيمة الشيك</th>
            <th>تاريخ الاستحقاق</th>
            <th>حالة الشيك</th>

        </tr>
    </thead>
    <tbody>
        <?php if($data->isEmpty()): ?>
            <tr>
                <td colspan="6" class="text-center">لا توجد بيانات</td>
            </tr>
        <?php else: ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key->check_number); ?></td>
                    <td>
                        <select onchange="update_check_type_ajax(<?php echo e($key->id); ?> , this.value)" class="form-control" name="" id="">
                            <option <?php if($key->check_type == 'outgoing'): ?> selected <?php endif; ?> value="outgoing">صادر</option>
                            <option <?php if($key->check_type == 'incoming'): ?> selected <?php endif; ?> value="incoming">وارد</option>
                        </select>





                    </td>
                    <td><?php echo e($key->user); ?></td>
                    <td>
                        <input type="text" onchange="update_check_amount_ajax(<?php echo e($key->id); ?> , this.value)" class="form-control" value="<?php echo e($key->amount); ?>">
                    </td>
                    <td><?php echo e($key->due_date); ?></td>
                    <td>
                        <select onchange="update_check_status(<?php echo e($key->id); ?>, this.value )" class="form-control" name="" id="">
                            <option <?php if($key->check_status == 'paid'): ?> selected <?php endif; ?> value="paid">مصروف</option>
                            <option <?php if($key->check_status == 'under_collection'): ?> selected <?php endif; ?> value="under_collection">في التحصيل</option>
                            <option <?php if($key->check_status == 'returned'): ?> selected <?php endif; ?> value="returned">راجع</option>
                            <option <?php if($key->check_status == 'portfolio'): ?> selected <?php endif; ?> value="portfolio">في المحفظة</option>
                        </select>









                    </td>




                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
</table>
<div id="pagination">
    <?php echo e($data->links()); ?>

</div>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/cheques/ajax/list_cheques_ajax.blade.php ENDPATH**/ ?>