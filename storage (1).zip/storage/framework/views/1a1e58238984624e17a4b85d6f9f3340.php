<div class="table-responsive">
    <table class="table table-hover border">
        <thead>
            <tr>
                <th>الرقم</th>
                <th>الصورة</th>
                <th>اسم الصنف</th>
                <th>اسم الصنف انجليزي</th>
                <th>الكمية</th>
                <th>الوحدة</th>
                <?php if($order->order_status == 0): ?>
                    <th>العمليات</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php if($data->isEmpty()): ?>
                <tr>
                    <td colspan="5" class="text-center"> لا توجد بيانات</td>
                </tr>
            <?php else: ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="delete_tr_<?php echo e($loop->index); ?>">
                        <td><?php echo e($loop->index + 1); ?></td>
                        <td>
                            <span class="mytooltip tooltip-effect-1">
                                <span class="tooltip-item"
                                    style='width: 65px;height: 50px;background-image: url("<?php echo e(asset('storage/product/' . $key['product']->product_photo)); ?>");background-size: contain;background-repeat: no-repeat;background-position: center'>

                                </span>
                                <span class="tooltip-content clearfix">
                                    <img
                                        src="<?php echo e(asset('storage/product/' . $key['product']->product_photo)); ?>">
                                </span>
                            </span>
                        </td>
                        <td>
                            <?php if(!empty($key['product']->product_name_ar)): ?>
                                <?php echo e($key['product']->product_name_ar); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <input onchange="edit_product_ajax(<?php echo e($key['product']->id); ?>)"
                                id="product_name_en_<?php echo e($key['product']->id); ?>" class="form-control"
                                type="text" value="<?php echo e($key['product']->product_name_en); ?>">
                        </td>
                        <td>
                            <input onchange="updateQty( this.value  , <?php echo e($key->id); ?>)"
                                id="qty_<?php echo e($loop->index); ?>" style="width: 80%" class="form-control"
                                type="number" value="<?php echo e($key->qty); ?>" placeholder="ادخل الكمية">
                        </td>
                        <td style="width: 150px">
                            <select onchange="updateUnit(this.value  , <?php echo e($key->id); ?>)"
                                name="product_id"
                                class="form-control select2bs4 select2-hidden-accessible"
                                style="width: 80%;" data-select2-id="<?php echo e($loop->index); ?>"
                                tabindex="-1" aria-hidden="true">
                                <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit_key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if(old(
                                            'unit_id',
                                            App\Models\OrderItemsModel::where('order_id', $order->id)->where('product_id', $key['product']->id)->value('unit_id')) == $unit_key->id): ?> selected <?php endif; ?>
                                        value="<?php echo e($unit_key->id); ?>"><?php echo e($unit_key->unit_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                        <td>
                            <button class="btn btn-danger btn-sm"
                                onclick="deleteItems(<?php echo e($key->id); ?> , <?php echo e($loop->index); ?>)">
                                <span class="fa fa-trash"></span>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/orders/procurement_officer/product/ajax/order_items_table.blade.php ENDPATH**/ ?>