<html dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>فاتورة مبيعات</title>
    <style>
        .table_invoice table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
            border-collapse: collapse;
        }

        .table_invoice td, th {
            border: 1px solid #dddddd;
            text-align: center;
            padding: 8px;
        }

        .table_invoice tr:nth-child(even) {
            background-color: #dddddd;
        }

        @page :first {
            <?php if(!empty($system_setting)): ?>
                background-image: url("<?php echo e(asset('storage/setting/'.$system_setting->letter_head_image)); ?>");
            <?php endif; ?>
            background-image-resize: 6;
            margin-bottom: 50px;
            margin-top: 220px;
        }
    </style>
</head>
<body>
    <h2 style="text-align: center">فاتورة مبيعات</h2>
    <div style="width: 100%">
        <table width="100%">
            <tr>
                <td colspan="">
                    <div>
                        <h3>الرقم المرجعي للفاتورة : <span><?php echo e($data->invoice_reference_number); ?></span></h3>
                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    <div>
                        <span>تاريخ الفاتورة : <span><?php echo e($data->bill_date); ?></span></span>
                    </div>
                </td>
                <td>
                    <div>
                        <span>تاريخ الاستحقاق : <span><?php echo e($data->due_date); ?></span></span>
                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    <div>
                        <span>الضريبة الاولى : <span><?php echo e($data->tax_id); ?></span></span>
                    </div>
                </td>
                <td>
                    <div>
                        <span>الضريبة الثانية : <span><?php echo e($data->tax_id2); ?></span></span>
                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    الملاحظات :
                    <?php echo e($data->note); ?>

                </td>
            </tr>
        </table>
    </div>
<div style="width: 100%">
    <table class="table_invoice" cellpadding="0" cellspacing="0" style="width: 100%;text-align: center">
        <tr>
            <th>الصنف</th>
            <th>الكمية</th>
            <th>السعر</th>
            <th>خصم</th>
            <th>بونص</th>
            <th>المجموع</th>
        </tr>
        <?php $__currentLoopData = $invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
                <td><?php echo e($key['product']->product_name_ar??''); ?></td>
            <td>
                <?php echo e($key->quantity ?? 1); ?>

            </td>
            <td>
                <?php echo e($key->rate ?? 1); ?>

            </td>
            <td>
                <?php echo e($key->discount ?? ''); ?>

            </td>
            <td>
                <?php echo e($key->bonus ?? ''); ?>

            </td>
            <td>
                <?php echo e(($key->quantity ?? 1) * ($key->rate ?? 1)); ?>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>
</div>

<div style="width: 100%;margin-top: 20px">
    <table cellpadding="0" cellspacing="0" style="width: 100%" class="table_invoice">
        <tr>
            <td class="" colspan="1">المجموع الكلي:</td>
            <td id="sub_total"><?php echo e($total); ?></td>
        </tr>
        <tr>
            <td colspan="1">الخصم:</td>
            <td>0</td>
        </tr>
        <tr>
            <td colspan="1">الرصيد المستحق:</td>
            <td id="sub_total_after_tax"><?php echo e($final_total); ?></td>
        </tr>
    </table>
</div>
</body>
</html>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/sales_invoices/invoices/pdf/sales_invoice.blade.php ENDPATH**/ ?>