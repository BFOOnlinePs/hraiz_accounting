<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <button onclick="delete_image(<?php echo e($key->id); ?>)" class="btn btn-danger"><span class="fa fa-trash"></span></button>
    <img style="width: 100px" src="<?php echo e(asset('storage/production/'.$key->attachment)); ?>" alt="">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/production/production_line/ajax/list_image.blade.php ENDPATH**/ ?>