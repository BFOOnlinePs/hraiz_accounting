<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <table>
        <tr>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($key->user_id); ?></td>
                <td><?php echo e($key->in_time); ?></td>
                <td><?php echo e($key->out_time); ?></td>
                <td><?php echo e($key->checked_by); ?></td>
                <td><?php echo e($key->note); ?></td>
                <td><?php echo e($key->attendance_id); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </table>
</body>
</html>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/hr/employees/pdf/attendance.blade.php ENDPATH**/ ?>