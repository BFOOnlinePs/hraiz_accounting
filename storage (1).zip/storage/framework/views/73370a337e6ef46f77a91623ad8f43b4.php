<?php $__env->startSection('title'); ?>
    الآلات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title'); ?>
    الآلات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_link'); ?>
    الاعدادات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title_link'); ?>
    الآلات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.messge_alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.messge_alert.fail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <button type="button" class="btn btn-dark" data-toggle="modal" data-target="#modal-lg">
        اضافة آلة
    </button>
    <div class="card mt-2">
        <div class="card-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>الاسم</th>
                                    <th>الوصف</th>
                                    <th>الصورة</th>
                                    <th>العمليات</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if(!$data->isEmpty()): ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key->machines_name); ?></td>
                                        <td><?php echo e($key->machines_description); ?></td>
                                        <td>
                                            <img style="width: 100px" src="<?php echo e(asset('storage/machine/'.$key->machines_image)); ?>" alt="">
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('setting.machine.edit',['id'=>$key->id])); ?>" class="btn btn-success btn-sm"><span class="fa fa-edit"></span></a>
                                            <a onclick="return confirm('هل انت متاكد من عملية الحذف ؟')" href="<?php echo e(route('setting.machine.delete',['id'=>$key->id])); ?>" class="btn btn-danger btn-sm"><span class="fa fa-trash"></span></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="text-center">لا توجد بيانات</td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modal-lg">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form action="<?php echo e(route('setting.machine.create')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                    <h4 class="modal-title">اضافة الة</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="">اسم الآلة</label>
                                <input class="form-control" name="machines_name" type="text" placeholder="اسم الآلة">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="">وصف الآلة</label>
                                <input class="form-control" name="machines_description" type="text" placeholder="اسم الآلة">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="">الصورة</label>
                                <input type="file" class="form-control" name="machines_image">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">اغلاق</button>
                    <button type="submit" class="btn btn-primary">حفظ</button>
                </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/setting/machine/index.blade.php ENDPATH**/ ?>