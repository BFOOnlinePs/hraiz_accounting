<?php $__env->startSection('title'); ?>
    الرئيسية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title'); ?>
    الرئيسية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_link'); ?>
    الرئيسية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title_link'); ?>
    الرئيسية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $userRoles = json_decode(auth()->user()->user_role, true); // Decode JSON string into PHP array
    ?>
    <?php if(in_array("1", $userRoles)): ?>
        <div class="row">
            <div class="col-lg-3 col-6">

                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?php echo e($order_count); ?></h3>
                        <p>الطلبيات</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-bag-shopping"></i>
                    </div>
                    <a href="<?php echo e(route('orders.procurement_officer.order_index')); ?>" class="small-box-footer">المزيد <i
                            class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <div class="col-lg-3 col-6">

                <div class="small-box bg-success">
                    <div class="inner">
                        <h3><?php echo e($product_count); ?></h3>
                        <p>الاصناف</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-list"></i>
                    </div>
                    <a href="<?php echo e(route('product.home')); ?>" class="small-box-footer">المزيد <i
                            class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <div class="col-lg-3 col-6">

                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3><?php echo e($supplier_count); ?></h3>
                        <p>الموردين</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-user"></i>
                    </div>
                    <a href="<?php echo e(route('users.supplier.index')); ?>" class="small-box-footer">المزيد <i
                            class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <div class="col-lg-3 col-6">

                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3><?php echo e($task_count); ?></h3>
                        <p>مهمة</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-tasks"></i>
                    </div>
                    <a href="<?php echo e(route('tasks.index')); ?>" class="small-box-footer">المزيد <i
                            class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>

        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <span class="">اخر الطلبيات</span>
                        <a href="<?php echo e(route('orders.procurement_officer.order_index')); ?>" class="btn btn-dark btn-sm" style="float: left">عرض الطلبيات</a>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="table-responsive">
                                <table id="example1"  class="table table-bordered table-hover text-center dataTable dtr-inline"
                                       aria-describedby="example1_info">
                                    <thead class="bg-dark">
                                    <tr>
                                        
                                        <th>ر.مرجعي</th>
                                        <th width="150">الترسية</th>
                                        <th>بواسطة</th>
                                        <th></th>
                                        <?php if(!in_array('3',json_decode(auth()->user()->user_role))): ?>
                                            <th>العمليات</th>
                                        <?php endif; ?>
                                        
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="">
                                            
                                            
                                            <td><?php echo e($key->reference_number); ?>

                                            
                                            <td>
                                                <?php $__currentLoopData = $key->supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($child['name']->name); ?>,
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td><?php echo e($key['user']->name); ?></td>
                                            <td><?php echo e($key->created_at); ?></td>
                                            <?php if(!in_array('3',json_decode(auth()->user()->user_role))): ?>
                                                <td>
                                                    <a href="<?php echo e(route('procurement_officer.orders.product.index',['order_id'=>$key->order_id])); ?>" class="btn btn-dark btn-sm"><span class="fa fa-search"></span></a>
                                                </td>
                                            <?php endif; ?>
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <span class="text-center">التقويم</span>
                        <a href="<?php echo e(route('calendar.index')); ?>" class="btn btn-dark btn-sm" style="float: left">عرض التقويم</a>
                    </div>

                    <div class="card-body">
                        <div id="calendar-ajax">
                            <div id="calendar"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php elseif(in_array("11", \GuzzleHttp\json_decode(auth()->user()->user_role))): ?>
        <div class="card">
            <div class="card-body">
                <table class="table table-sm table-bordered">
                    <thead>
                        <tr>
                            <th>خط الانتاج</th>
                            <th>الموظف</th>
                            <th>الحالة</th>
                            <th>تاريخ الانشاء</th>
                            <th>تاريخ التسليم</th>
                            <th>الكمية</th>
                            <th>الملاحظات</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if($production_orders->isEmpty()): ?>
                        <tr>
                            <td colspan="7" class="text-center">لا توجد بيانات</td>
                        </tr>
                    <?php else: ?>
                        <?php $__currentLoopData = $production_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key->production_lines->production_name); ?></td>
                                <td><?php echo e($key->user->name); ?></td>
                                <td><?php echo e($key->status); ?></td>
                                <td><?php echo e($key->insert_at); ?></td>
                                <td><?php echo e($key->submission_date); ?></td>
                                <td><?php echo e($key->qty); ?></td>
                                <td><?php echo e($key->notes); ?></td>
                                <td>
                                    <a class="btn btn-dark btn-sm" href="<?php echo e(route('production.production_inputs.index',['id'=>$key->production_lines->id])); ?>"><span class="fa fa-search"></span></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script
        src='<?php echo e(asset('assets/calendar/js/cdn.jsdelivr.net_npm_fullcalendar@6.1.8_index.global.min.js')); ?>'></script>
    <script>

        function CalendarJs() {
            document.addEventListener('DOMContentLoaded', function () {
                var calendarEl = document.getElementById('calendar');
                var calendar = new FullCalendar.Calendar(calendarEl, {
                    initialView: 'dayGridMonth',
                    headers: {
                        center: 'title'
                    },
                    editable: false,
                    events: '<?php echo e(route('calendar.getEvents')); ?>',
                    eventResize(event, delta) {
                        alert(event);
                    },
                    eventRender: function (event, element, view) {
                        if (event.allDay === 'true') {
                            event.allDay = true;
                        } else {
                            event.allDay = false;
                        }
                    },
                    selectable: true,
                    selectHelper: true,
                    select: function (start, end, allDay, startStr) {
                        var modal = $('#modal-lg-calendar').modal();
                        var submit_button = document.getElementById('submit_button');
                        submit_button.addEventListener("click", function () {
                            $.ajax({
                                url: "<?php echo e(route('procurement_officer.orders.calender.create')); ?>",
                                type: "POST",
                                headers: {
                                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                },
                                data: {
                                    start: start['startStr'],
                                },
                                success: function (data) {
                                    console.log(data);
                                    // calendar.refetchEvents();
                                    calendar.addEvent({
                                        id: data.id,
                                        start: data['start'],
                                    });

                                    calendar.unselect();
                                    $('#modal-lg-calendar').modal('hide');

                                }
                            });
                        });

                    },
                    // events: [
                    //     {
                    //         title: 'event1',
                    //         start: '2023-08-14',
                    //     },
                    //     {
                    //         title: 'event2',
                    //         start: '2023-08-12',
                    //         end: '2023-08-18',
                    //     },
                    //     {
                    //         title: 'event3',
                    //         start: '2023-08-14T12:30:00',
                    //         allDay: false // will make the time show
                    //     }
                    // ],


                    
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                    direction: 'rtl',
                    dateClick: function (info) {
                        // The info parameter contains information about the clicked day
                        var clickedDate = info;
                        // console.log(info);
                        // $('#modal-lg-calendar').modal();
                        // Perform your custom action here
                    }
                });
                calendar.render();
            });

        }

        
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            window.onload = CalendarJs();
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/home.blade.php ENDPATH**/ ?>