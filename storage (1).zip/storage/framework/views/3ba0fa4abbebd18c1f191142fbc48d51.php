<div class="pb-2 row d-flex justify-content-center">
    <a class="btn btn-app <?php if(!\App\Models\OrderItemsModel::where('order_id',$order->id)->get()->isEmpty()): ?> bg-gradient-success <?php else: ?> bg-gradient-info <?php endif; ?> text-white"  href="<?php echo e(route('procurement_officer.orders.product.index',['order_id'=>$order->id])); ?>">
        <i class="fa fa-list">

        </i>
        الأصناف
    </a>
    <a class="btn btn-app <?php if(!\App\Models\PriceOffersModel::where('order_id',$order->id)->get()->isEmpty()): ?> bg-gradient-success <?php else: ?> bg-gradient-info <?php endif; ?> text-white" href="<?php echo e(route('procurement_officer.orders.price_offer.index',['order_id'=>$order->id])); ?>">
        <i class="fa fa-bars">

        </i>
        عروض الأسعار
    </a>
    <a class="btn btn-app <?php if(!\App\Models\PriceOffersModel::where('order_id',$order->id)->where('status',1)->get()->isEmpty()): ?> bg-gradient-success <?php else: ?> bg-gradient-info <?php endif; ?> text-white" href="<?php echo e(route('procurement_officer.orders.anchor.index',['order_id'=>$order->id])); ?>">
        <i class="fa fa-thumbs-up">

        </i>
        الترسية
    </a>
    <a class="btn btn-app <?php if(!(\App\Models\CashPaymentsModel::where('order_id',$order->id)->get()->isEmpty()) || !(\App\Models\LetterBankModel::where('order_id',$order->id)->get()->isEmpty())): ?> bg-gradient-success <?php else: ?> bg-gradient-info <?php endif; ?> text-white" href="<?php echo e(route('procurement_officer.orders.financial_file.index',['order_id'=>$order->id])); ?>">
        <i class="fa fa-dollar">

        </i>
        الملف المالي
    </a>
    <a class="btn btn-app <?php if(!\App\Models\ShippingPriceOfferModel::where('order_id',$order->id)->get()->isEmpty()): ?> bg-gradient-success <?php else: ?> bg-gradient-info <?php endif; ?> text-white" href="<?php echo e(route('procurement_officer.orders.shipping.index',['order_id'=>$order->id])); ?>">
        <i class="fa fa-plane">

        </i>
        شحن
    </a>
    <a class="btn btn-app <?php if(!\App\Models\OrderInsuranceModel::where('order_id',$order->id)->get()->isEmpty()): ?> bg-gradient-success <?php else: ?> bg-gradient-info <?php endif; ?> text-white" href="<?php echo e(route('procurement_officer.orders.insurance.index',['order_id'=>$order->id])); ?>">
        <i class="fa fa-file-alt">

        </i>
        تأمين
    </a>
    <a class="btn btn-app <?php if(!\App\Models\OrderClearanceModel::where('order_id',$order->id)->get()->isEmpty()): ?> bg-gradient-success <?php else: ?> bg-gradient-info <?php endif; ?> text-white" href="<?php echo e(route('procurement_officer.orders.clearance.index',['order_id'=>$order->id])); ?>">
        <i class="fa fa-file-import">

        </i>
        تخليص
    </a>
    <a class="btn btn-app <?php if(!\App\Models\OrderLocalDeliveryModel::where('order_id',$order->id)->get()->isEmpty()): ?> bg-gradient-success <?php else: ?> bg-gradient-info <?php endif; ?> text-white" href="<?php echo e(route('procurement_officer.orders.delivery.index',['order_id'=>$order->id])); ?>">
        <i class="fa fa-car">

        </i>
        توصيل
    </a>
    <a class="btn btn-app bg-gradient-info text-white" href="<?php echo e(route('procurement_officer.orders.calender.index',['order_id'=>$order->id])); ?>">
        <i class="fa fa-calendar">

        </i>
        تقويم
    </a>
    <a class="btn btn-app bg-gradient-info text-white" href="<?php echo e(route('procurement_officer.orders.attachment.index',['order_id'=>$order->id])); ?>">
        <i class="fa fa-paperclip">

        </i>
        مرفقات
    </a>
    <a class="btn btn-app bg-gradient-info text-white" href="<?php echo e(route('procurement_officer.orders.notes.index',['order_id'=>$order->id])); ?>">
        <i class="fa fa-note-sticky">

        </i>
        ملاحظات
    </a>
    <a class="btn btn-app bg-gradient-info text-white" href="<?php echo e(route('procurement_officer.orders.forms.index',['order_id'=>$order->id])); ?>">
        <i class="fa fa-file-circle-check">

        </i>
        نماذج
    </a>
    <a class="btn btn-app bg-gradient-info text-white" href="<?php echo e(route('procurement_officer.orders.invoices.index',['order_id'=>$order->id])); ?>">
        <i class="fas fa-file-invoice"></i>
        فواتير
    </a>






</div>

<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/orders/order_menu.blade.php ENDPATH**/ ?>