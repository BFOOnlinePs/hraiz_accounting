<?php $__env->startSection('title'); ?>
    الضرائب
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title'); ?>
الضرائب
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_link'); ?>
    الاعدادات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title_link'); ?>
الضرائب
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.messge_alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.messge_alert.fail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <button type="button" class="btn btn-dark mb-2" data-toggle="modal" data-target="#modal-lg">
        اضافة ضريبة
    </button>
    <div class="card">

        

        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>اسم الضريبة</th>
                        <th>نسبة الضريبة</th>
                        <th>العمليات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($data->isEmpty()): ?>
                        <tr>
                            <td colspan="3" class="text-center">لا توجد بيانات</td>
                        </tr>
                    <?php else: ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key->tax_name); ?></td>
                        <td><?php echo e($key->tax_ratio); ?></td>
                        <td>
                            <a href="<?php echo e(route('accounting.texes.edit',['id'=>$key->id])); ?>" class="btn btn-success btn-sm"><span class="fa fa-edit"></span></a>
                            <a onclick="return confirm('هل تريد حذف البيانات ؟')" href="<?php echo e(route('accounting.texes.delete',['id'=>$key->id])); ?>" class="btn btn-danger btn-sm"><span class="fa fa-trash"></span></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>
    <div class="modal fade" id="modal-lg">
        <div class="modal-dialog modal-lg">
            <form action="<?php echo e(route('accounting.texes.create')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">اضافة ضريبة</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">اسم الضريبة</label>
                                    <input required type="text" class="form-control" name="tax_name" placeholder="اسم الضريبة">
                                </div>
                                <div class="form-group">
                                    <label for="">نسبة الضريبة</label>
                                    <input required type="text" class="form-control" name="tax_ratio" placeholder="اسم الضريبة">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">اغلاق</button>
                        <button type="submit" class="btn btn-primary">حفظ</button>
                    </div>

                </div>
            </form>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/taxes/index.blade.php ENDPATH**/ ?>