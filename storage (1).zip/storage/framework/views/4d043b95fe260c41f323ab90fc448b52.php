<div class="table-responsive">
  <table style="width:100%" class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>صورة</th>
            <th>باركود</th>
            <th>اسم الصنف</th>
            <th>اسم الصنف EN</th>
            <th>المجموعة</th>
            <th>الوحدة</th>


            <th>حالة الصنف</th>
            <th>العمليات</th>
        </tr>
    </thead>
    <tbody id="tableBody">
    <?php if(!$data->isEmpty()): ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php if(empty($key->product_photo)): ?>
                        <img src="<?php echo e(asset('img/no_img.jpeg')); ?>" width="50" alt="">
                    <?php else: ?>
                        <span class="mytooltip tooltip-effect-1">
                                <span class="tooltip-item"
                                      style='width: 65px;height: 50px;background-image: url("<?php echo e(asset('storage/product/' . $key->product_photo)); ?>");background-size: contain;background-repeat: no-repeat;background-position: center'>

                                </span>
                                <span class="tooltip-content clearfix">
                                    <img src="<?php echo e(asset('storage/product/' . $key->product_photo)); ?>">
                                </span>
                            </span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php echo e($key->barcode); ?>

                </td>
                <td>
                    <input onchange="edit_product_ajax(<?php echo e($key->id); ?>)"
                           id="product_name_ar_<?php echo e($key->id); ?>" class="form-control" type="text"
                           value="<?php echo e($key->product_name_ar); ?>">
                </td>
                <td>
                    <input onchange="edit_product_ajax(<?php echo e($key->id); ?>)"
                           id="product_name_en_<?php echo e($key->id); ?>" class="form-control" type="text"
                           value="<?php echo e($key->product_name_en); ?>">
                </td>
                <td>
                    <?php if(!empty($key['category']->cat_name)): ?>
                        <?php echo e($key['category']->cat_name); ?>

                    <?php endif; ?>
                </td>
                <td><?php echo e($key['unit']->unit_name); ?></td>
                
                
                

                
                
                <td>
                    <?php if($key->product_status): ?>
                        <small class="badge btn-success">فعال</small>
                    <?php else: ?>
                        <small class="badge badge-danger">غير فعال</small>
                    <?php endif; ?>
                </td>
                <td>
                    
                    
                    <a href="<?php echo e(route('product.details', ['id' => $key->id])); ?>"
                       class="btn btn-dark btn-sm"><span class="fa fa-search"></span></a>
                    
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <tr>
            <td colspan="8" class="text-center">لا توجد نتائج</td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
<div id="paginationLinks">
    <?php echo e($data->links()); ?>

</div>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/product/ajax/search_product.blade.php ENDPATH**/ ?>