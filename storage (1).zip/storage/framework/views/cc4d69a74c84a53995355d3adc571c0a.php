<html dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>كشف حساب عميل</title>
    <style>
        .tbb { border-collapse: collapse; width:400px; }
        .tbb th, .tbb td { padding: 5px; border: solid 1px black; }
        /*.tbb th { background-color: aliceblue; }*/
        .tbb { width: 100% }

        @page{
            <?php if(!empty(\App\Models\SystemSettingModel::first()->letter_head_image)): ?>
                background-image: url("<?php echo e(asset('storage/setting/'.\App\Models\SystemSettingModel::first()->letter_head_image)); ?>");
            <?php endif; ?>
            background-image-resize: 6;
            header: page-header;
            footer: page-footer;
            margin-top: 130px;
        }

        @page :first {
            <?php if(!empty(\App\Models\SystemSettingModel::first()->letter_head_image)): ?>
                background-image: url("<?php echo e(asset('storage/setting/'.\App\Models\SystemSettingModel::first()->letter_head_image)); ?>");
            <?php endif; ?>
            background-image-resize: 6;
            /*margin-bottom: 50px;*/
            /*margin-top: 220px;*/
        }
    </style>

</head>
<body>
    <h3 style="text-align: center">كشف حساب</h3>
    <p>اسم الزبون : <span><?php echo e($user->name); ?></span></p>
    <p>التاريخ : <span><?php echo e(\Carbon\Carbon::now()->toDateString()); ?></span></p>
    <table width="100%" class="tbb">
        <tr>
            <th>المستند</th>
            <th>التاريخ</th>
            <th>دائن</th>
            <th>مدين</th>
            <th>الرصيد</th>
            <th>البيان</th>
        </tr>
        <?php
            $sumCreditor = 0;
            $sumDebtor = 0;
            $amount = 0;
        ?>
        <?php if($data->isEmpty()): ?>
            <tr>
                <td colspan="6" style="text-align: center">لا توجد بيانات</td>
            </tr>
        <?php else: ?>
            <tr>
                <td></td>
                <td></td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>رصيد اول المدة</td>
            </tr>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key->reference_number); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($key->created_at)->format('Y-m-d')); ?></td>
                    <td>
                        <?php if($key->type == 'purchase' || $key->type == 'payment_bond' || $key->type == 'return_sales'): ?>
                            <?php echo e($key->amount); ?>

                            <?php
                                $sumCreditor += $key->amount;
                                $amount -= $key->amount;
                            ?>
                        <?php else: ?>
                            0
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($key->type == 'sales' || $key->type == 'performance_bond' || $key->type == 'return_purchase'): ?>
                            <?php echo e($key->amount); ?>

                            <?php
                                $sumDebtor += $key->amount;
                                $amount += $key->amount;
                            ?>
                        <?php else: ?>
                            0
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($amount); ?></td>
                    <td>
                        <?php if($key->type == 'sales'): ?>
                            فاتورة مبيعات
                        <?php elseif($key->type == 'payment_bond'): ?>
                            سند قبض
                        <?php elseif($key->type == 'return_sales'): ?>
                            مردود مبيعات
                        <?php elseif($key->type == 'purchase'): ?>
                            فاتورة مشتريات
                        <?php elseif($key->type == 'performance_bond'): ?>
                            سند صرف
                        <?php elseif($key->type == 'return_purchase'): ?>
                            مردود مشتريات
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr class="bg-dark">
                <td></td>
                <td colspan="" class="text-center">المجموع</td>
                <td><?php echo e($sumCreditor); ?></td>
                <td><?php echo e($sumDebtor); ?></td>
                <td><?php echo e($sumDebtor - $sumCreditor); ?></td>
                <td></td>
            </tr>
        <?php endif; ?>
    </table>
</body>
</html>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/account_statement/pdf/account_statement_details_pdf.blade.php ENDPATH**/ ?>