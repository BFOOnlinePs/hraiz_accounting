<div class="card">
    <div class="card-body">
        <h4 class="">الدفعات النقدية</h4>
        <?php if($cash_payment && !$cash_payment->isEmpty()): ?>
            <table class="table table-sm table-hover table-bordered" cellpadding="10">
                <tr class="bg-info">
                    <th></th>
                    <th>مرجعي</th>
                    <th>اسم المورد</th>
                    <th>حالة الدفعة</th>
                    <th>تاريخ الاضافة</th>
                    <th>
                        <div style="display: inline;float: right">
                            تاريخ الاستحقاق
                        </div>
                        <div style="display: inline;float: left">
                            <span style="font-size: 9px;float: left;clear: both" onclick="data_table_ajax('','','due_date','asc')" class="fa fa-chevron-up"></span>
                            <span style="font-size: 9px;float: left;clear: both" onclick="data_table_ajax('','','due_date','desc')" class="fa fa-chevron-down mt-1"></span>
                        </div>
                    </th>
                    <th>تاريخ الدفع</th>
                    <th>نوع الدفعة</th>
                    <th>مبلغ الدفعة</th>
                </tr>

                <?php $__currentLoopData = $cash_payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php if(!empty($key->attachment)): ?>
                                
                                
                                
                                
                                <a
                                    onclick="viewAttachment('<?php echo e(asset('storage/attachment/'.$key->attachment)); ?>')"
                                    href="" class="text-dark" data-toggle="modal"
                                    data-target="#modal-lg-view_attachment"><span
                                        class="fa fa-eye"></span></a>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a target="_blank" href="<?php echo e(route('procurement_officer.orders.product.index',['order_id'=>$key->order_id])); ?>"><?php echo e(\App\Models\OrderModel::where('id',$key->order_id)->value('reference_number')); ?></a>
                        </td>
                        <td>
                            <a href="<?php echo e(route('users.supplier.details',['id'=> App\Models\User::where('id',$request->supplier_id)->value('id') ?? \App\Models\User::where('id',\App\Models\PriceOffersModel::where('order_id',$key->order_id)->value('supplier_id'))->value('id')])); ?>"><?php echo e(App\Models\User::where('id',$request->supplier_id)->value('name') ?? \App\Models\User::where('id',\App\Models\PriceOffersModel::where('order_id',$key->order_id)->value('supplier_id'))->value('name')); ?></a>
                        </td>
                        <td <?php if($key->payment_status == 1): ?> class="bg-success" <?php endif; ?>>
                            <?php if($key->payment_status == 0): ?>
                                بانتظار الدفع
                            <?php elseif($key->payment_status == 1): ?>
                                مدفوعة
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(\Carbon\Carbon::parse($key->insert_at)->toDateString()); ?></td>
                        <td><?php echo e($key->due_date); ?></td>
                        <td><?php echo e($key->payment_date); ?></td>
                        <td>
                            <?php if($key->payment_type == 1): ?>
                                نقدية
                            <?php elseif($key->payment_type == 2): ?>
                                مؤجلة
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo e($key->amount); ?>

                            &nbsp;
                            <span style="float: left" class="text-danger">(<?php echo e($key->currency->currency_name ?? ''); ?>)</span>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-dark">
                    <td colspan="8"></td>
                    <td>
                        <?php $__currentLoopData = $cash_payment_currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <span colspan="8" class="text-center"><?php echo e($key->currency_name); ?></span>
                                <span><?php echo e($key->sum ?? ''); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>

                
                
                
                
            </table>
            
            
            
        <?php endif; ?>

    </div>
</div>
<div class="card">
    <div class="card-body">
        <h4 class="mt-2">الاعتمادات البنكية</h4>
        <?php if($letter_bank && !$letter_bank->isEmpty()): ?>
            <table class="table table-sm table-hover table-bordered" cellpadding="10">
                <tr class="bg-info">
                    <th></th>
                    <th>مرجعي</th>
                    <th>اسم المورد</th>
                    <th>البنك</th>
                    <th>نوع الاعتماد</th>
                    <th>
                        <div style="display: inline;float: right">
                            تاريخ الاستحقاق
                        </div>
                        <div style="display: inline;float: left">
                            <span style="font-size: 9px;float: left;clear: both" onclick="data_table_ajax('','','due_date','asc')" class="fa fa-chevron-up"></span>
                            <span style="font-size: 9px;float: left;clear: both" onclick="data_table_ajax('','','due_date','desc')" class="fa fa-chevron-down mt-1"></span>
                        </div>
                    </th>
                    <th>ملاحظات</th>
                    <th>السعر</th>
                </tr>

                <?php $__currentLoopData = $letter_bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php if(!empty($key->attachment)): ?>
                                
                                
                                
                                
                                <a
                                    onclick="viewAttachment('<?php echo e(asset('storage/attachment/'.$key->attachment)); ?>')"
                                    href="" class="text-dark" data-toggle="modal"
                                    data-target="#modal-lg-view_attachment"><span
                                        class="fa fa-eye"></span></a>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a target="_blank" href="<?php echo e(route('procurement_officer.orders.product.index',['order_id'=>$key->order_id])); ?>"><?php echo e(\App\Models\OrderModel::where('id',$key->order_id)->value('reference_number')); ?></a>
                        </td>
                        <td>
                            <a href="<?php echo e(route('users.supplier.details',['id'=> App\Models\User::where('id',$request->supplier_id)->value('id') ?? \App\Models\User::where('id',\App\Models\PriceOffersModel::where('order_id',$key->order_id)->value('supplier_id'))->value('id')])); ?>"><?php echo e(App\Models\User::where('id',$request->supplier_id)->value('name') ?? \App\Models\User::where('id',\App\Models\PriceOffersModel::where('order_id',$key->order_id)->value('supplier_id'))->value('name')); ?></a>
                        </td>
                        <td><?php echo e($key->bank->user_bank_name); ?></td>
                        <td>
                            <?php if($key->letter_type == 1): ?>
                                اعتماد دفع
                            <?php elseif($key->letter_type == 2): ?>
                                اعتماد حين الطلب
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($key->due_date); ?></td>
                        <td><?php echo e($key->notes); ?></td>
                        <td>
                            <?php echo e($key->letter_value); ?>

                            &nbsp;
                            <span style="float: left" class="text-danger">(<?php echo e($key->currency->currency_name ?? ''); ?>)</span>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-dark">
                    <td colspan="7"></td>
                    <td>
                        <?php $__currentLoopData = $letter_bank_currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <span colspan="7" class="text-center"><?php echo e($key->currency_name); ?></span>
                                <span><?php echo e($key->sum ?? ''); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>

                
                
                
                
            </table>
            
            
            
        <?php endif; ?>

    </div>
</div>

<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/reports/financial_report/ajax/data_table.blade.php ENDPATH**/ ?>