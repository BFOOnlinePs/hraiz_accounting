<table class="table table-hover table-bordered table-sm" aria-describedby="example1_info">
    <thead>
        <tr>
            <th>المنتج</th>
            <th>الصنف باللغة الانجليزية</th>
            <th>
                العمليات
            </th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $product_supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key['product']->product_name_ar ?? ''); ?></td>
                <td>
                    <input onchange="edit_product_ajax(<?php echo e($key['product']->id); ?>)"
                        id="product_name_en_<?php echo e($key['product']->id); ?>" class="form-control" type="text"
                        value="<?php echo e($key['product']->product_name_en); ?>">
                </td>
                <td>
                    <a href="<?php echo e(route('users.supplier.delete_product_supplier', ['id' => $key->id])); ?>"
                        onclick="return confirm('هل انت متاكد من عملية الحذف ؟')" class="btn btn-danger btn-sm"><span
                            class="fa fa-trash"></span></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/users/supplier/ajax/product_list.blade.php ENDPATH**/ ?>