<table class="table table-sm table-bordered table-hover">
    <thead>
        <tr>
            <th>اسم خط الانتاج</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
    <?php if($data->isEmpty()): ?>
        <tr>
            <td colspan="2" class="text-center">لا توجد بيانات</td>
        </tr>
    <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key->production_name); ?></td>
                <td>
                    <a href="<?php echo e(route('production.production_inputs.index',['id'=>$key->id])); ?>" class="btn btn-sm btn-dark"><span class="fa fa-search"></span></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </tbody>
</table>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/production/production_line/ajax/product_production_line_table.blade.php ENDPATH**/ ?>