<div class="row">
    <div class="col-md-12">
        <table style="width: 100%" class="table-striped table-hover">
            <thead>
            <tr>
                <th></th>
                <th style="width: 400px">الصنف</th>
                <th>الكمية</th>
                <th>السعر</th>
                <th>خصم</th>
                <th>بونص</th>
                <th>المجموع</th>
            </tr>
            </thead>
            <tbody>
            <?php if($data->isEmpty()): ?>
                <tr>
                    <td class="text-center" colspan="6">لا توجد بيانات</td>
                </tr>
            <?php else: ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="item_row_<?php echo e($key->id); ?>">
                        <td>
                            <?php if(!empty($key['product']->product_photo)): ?>
                                <img width="50" src="<?php echo e(asset('storage/product/'.$key["product"]->product_photo??'')); ?>" alt="">
                            <?php else: ?>
                                <img width="50" src="<?php echo e(asset('img/no_img.jpeg')); ?>" alt="">
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($key['product']->product_name_ar??''); ?></td>
                        <td>
                            <input <?php if($invoice->status == 'stage'): ?> disabled <?php endif; ?> class="input" id="qty_input_<?php echo e($key->id); ?>" onchange="edit_inputs_from_invoice(<?php echo e($key->id); ?>,this.value,'qty')" type="text" value="<?php echo e($key->quantity ?? 1); ?>">
                        </td>
                        <td>
                            <input <?php if($invoice->status == 'stage'): ?> disabled <?php endif; ?> class="input" id="rate_input_<?php echo e($key->id); ?>" onchange="edit_inputs_from_invoice(<?php echo e($key->id); ?>,this.value,'rate')" type="text" value="<?php echo e($key->rate ?? 1); ?>">
                        </td>
                        <td>
                            <input <?php if($invoice->status == 'stage'): ?> disabled <?php endif; ?> class="input" style="width: 40px" onchange="edit_inputs_from_invoice(<?php echo e($key->id); ?>, this.value, 'discount')" type="text" value="<?php echo e($key->discount ?? ''); ?>"> %
                        </td>
                        <td>
                            <input <?php if($invoice->status == 'stage'): ?> disabled <?php endif; ?> class="input" onchange="edit_inputs_from_invoice(<?php echo e($key->id); ?>, this.value, 'bonus')" type="text" value="<?php echo e($key->bonus ?? ''); ?>">
                        </td>
                        <td id="total_td_<?php echo e($key->id); ?>"></td>
                        <td>
                            <button <?php if($invoice->status == 'stage'): ?> disabled <?php endif; ?> onclick="delete_item(<?php echo e($key->id); ?>)" class="btn btn-danger btn-sm"><span class="fa fa-close"></span></button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>
            </tbody>
        </table>
        <div class="row mt-3">
            <div class="col-md-6">

            </div>
            <div class="col-6">
                <div class="table-responsive">
                    <table class="table">
                        <tbody><tr>
                            <th style="width:50%">المجموع الكلي:</th>
                            <td class="" id="sub_total"></td>
                            <td></td>
                        </tr>
                        <tr>
                            <th>الخصم:</th>
                            <td class="">0</td>
                            <td></td>
                        </tr>
                        <tr>
                            <th><?php echo e($invoice->tax->tax_name??''); ?> (<?php echo e($invoice->tax->tax_ratio??''); ?>)%:</th>
                            <td class="" id="tax_id"></td>
                            <td>
                                <button type="button" class="btn btn-info btn-sm rounded-circle" data-toggle="modal" data-target="#discount-modal">
                                    <span class="fa fa-edit"></span>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <th>الرصيد المستحق:</th>
                            <td class="" id="sub_total_after_tax"></td>
                            <td></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>























    </div>
</div>

        <script>
            var sub_total = 0;
            var tax = 0;
            var sub_total_after_tax = 0;
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                sub_total += updateTotal(<?php echo e($key->id); ?>);
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            tax = ((sub_total * <?php echo e($invoice->tax->tax_ratio??0); ?>) / 100);
            if(document.getElementById('tax_type').value == 'before'){
                sub_total_after_tax = sub_total ;
            }
            else if(document.getElementById('tax_type').value == 'after'){
                sub_total_after_tax = sub_total + ((sub_total * <?php echo e($invoice->tax->tax_ratio??0); ?>) / 100);
            }
            document.getElementById('sub_total').innerText = sub_total;
            document.getElementById('tax_id').innerText = tax;
            document.getElementById('sub_total_after_tax').innerText = sub_total_after_tax.toFixed(2);


            function updateSubTotal() {
                var sub_total = 0;
                var tax = 0;
                var sub_total_after_tax = 0;
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    sub_total += updateTotal(<?php echo e($key->id); ?>);
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                tax = ((sub_total * <?php echo e($invoice->tax->tax_ratio??0); ?>) / 100);
                if(document.getElementById('tax_type').value == 'before'){
                    sub_total_after_tax = sub_total ;
                }
                else if(document.getElementById('tax_type').value == 'after'){
                    sub_total_after_tax = sub_total + ((sub_total * <?php echo e($invoice->tax->tax_ratio??0); ?>) / 100);
                }
                document.getElementById('sub_total').innerText = sub_total;
                document.getElementById('tax_id').innerText = tax;
                document.getElementById('sub_total_after_tax').innerText = sub_total_after_tax;
                return sub_total;
            }
            function updateTotal(itemId) {
            var qty = parseFloat(document.getElementById('qty_input_' + itemId).value) || 0;
            var rate = parseFloat(document.getElementById('rate_input_' + itemId).value) || 0;
            var total = qty * rate;
            document.getElementById('total_td_' + itemId).innerText = total;
            return total;
        }

        $(".input").keypress(function(event) {
            var regex = /^[0-9\s]+$/;
            var inputChar = String.fromCharCode(event.which);

            if (regex.test(inputChar)) {
                return true;
            }

            return false;
        });

            function update_tax_type(){
                update_tax_id_ratio();
                document.getElementById('tax_type').value;
                updateSubTotal();
                $('#discount-modal').modal('hide');
                invoices_table();
            }
        </script>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/purchase_invoices/invoices/ajax/invoices_table.blade.php ENDPATH**/ ?>