<?php $__env->startSection('title'); ?>
    عرض شراء
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title'); ?>
    <span>عرض شراء <span>
            <?php if($order->reference_number != 0): ?>
                #<?php echo e($order->reference_number); ?>

            <?php endif; ?>
        </span></span>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_link'); ?>
    الرئيسية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title_link'); ?>
    تفاصيل عرض شراء
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/toastr/toastr.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
    <style>
        /* أنماط CSS لشاشة التحميل */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            /* خلفية شفافة لشاشة التحميل */
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            /* يجعل شاشة التحميل فوق جميع العناصر الأخرى */
        }

        .loader {
            border: 4px solid #f3f3f3;
            /* لون الدائرة الخارجية */
            border-top: 4px solid #3498db;
            /* لون الدائرة الداخلية */
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 2s linear infinite;
            /* تأثير دوران */
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }
    </style>
    <style>
        .mt-100 {
            margin-top: 150px;
            margin-left: 200px
        }

        /*.card-header {*/
        /*    background-color: #9575CD*/
        /*}*/
        h5 {
            color: #fff
        }

        .card-block {
            margin-top: 10px
        }

        .mytooltip {
            display: inline;
            position: absolute;
            z-index: 999
        }

        .mytooltip .tooltip-item {
            background: rgba(0, 0, 0, 0.1);
            cursor: pointer;
            display: inline-block;
            font-weight: 500;
            padding: 0 10px
        }

        .mytooltip .tooltip-content {
            position: absolute;
            z-index: 9999;
            width: 500px;
            right: 40px;
            /*left: 50%;*/
            margin: 0 0 -40px -180px;
            bottom: 100%;
            text-align: left;
            font-size: 14px;
            line-height: 30px;
            -webkit-box-shadow: -5px -5px 15px rgba(48, 54, 61, 0.2);
            box-shadow: -5px -5px 15px rgba(48, 54, 61, 0.2);
            background: #2b2b2b;
            opacity: 0;
            cursor: default;
            pointer-events: none
        }

        .mytooltip .tooltip-content::after {
            content: '';
            top: 100%;
            right: 0px;
            border: solid transparent;
            height: 0;
            width: 0;
            position: absolute;
            pointer-events: none;
            border-color: #2a3035 transparent transparent;
            border-width: 10px;
            margin-left: -10px
        }

        .mytooltip .tooltip-content img {
            position: relative;
            width: 100%;
            display: block;
            float: left;
            margin-right: 1em
        }

        .mytooltip .tooltip-item::after {
            content: '';
            position: absolute;
            width: 360px;
            height: 20px;
            bottom: 100%;
            left: 50%;
            pointer-events: none;
            -webkit-transform: translateX(-50%);
            transform: translateX(-50%)
        }

        .mytooltip:hover .tooltip-item::after {
            pointer-events: auto
        }

        .mytooltip:hover .tooltip-content {
            pointer-events: auto;
            opacity: 1;
            -webkit-transform: translate3d(0, 0, 0) rotate3d(0, 0, 0, 0deg);
            transform: translate3d(0, 0, 0) rotate3d(0, 0, 0, 0deg)
        }

        .mytooltip:hover .tooltip-content2 {
            opacity: 1;
            font-size: 18px
        }

        .mytooltip .tooltip-text {
            font-size: 14px;
            line-height: 24px;
            display: block;
            padding: 1.31em 1.21em 1.21em 0;
            color: #fff
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('admin.messge_alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.messge_alert.fail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.orders.order_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="text-center">عروض الأسعار</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-12">
                    <button type="button" class="btn btn-dark mb-2" data-toggle="modal"
                        data-target="#modal-lg-offer_price">
                        <span class="fa fa-plus"></span> اضافة عرض سعر
                    </button>
                    <a class="btn btn-success mb-2"
                        href="<?php echo e(route('procurement_officer.orders.price_offer.exportExcel', ['order_id' => $order->id])); ?>">تصدير
                        الى اكسيل</a>
                </div>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12 col-sm-6 col-12">
                        <div class="info-box bg-info">
                            
                            <div class="info-box-content">
                                <div class="row">
                                    <div class="col-md-10">
                                        <span class="info-box-text"><?php echo e($key['supplier']->name); ?></span>
                                        <div class="progress">
                                            <div class="progress-bar" style="width: 100%"></div>
                                        </div>
                                        <span>
                                            <?php echo e($key->notes); ?>

                                        </span>
                                        <div class="progress">
                                            <div class="progress-bar" style="width: 100%"></div>
                                        </div>
                                        <div class="table-responsive mt-2">
                                            <table class="table bg-white table-bordered table-hover">
                                                <thead>
                                                    <tr class="text-center">
                                                        <th>الرقم</th>
                                                        <th>الصورة</th>
                                                        <th>اسم الصنف</th>
                                                        <th>الكمية</th>
                                                        <th>الوحدة</th>
                                                        <th>السعر</th>
                                                        <th>بونص</th>
                                                        <th>خصم %</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php if($order_items->isEmpty()): ?>
                                                        <tr>
                                                            <td colspan="5" class="text-center">
                                                                <span>لا توجد بيانات</span>
                                                            </td>
                                                        </tr>
                                                    <?php else: ?>
                                                        <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($loop->index + 1); ?></td>
                                                                <td>
                                                                    <span class="mytooltip tooltip-effect-1">
                                                                        <span class="tooltip-item"
                                                                            style='width: 65px;height: 50px;background-image: url("<?php echo e(asset('storage/product/' . $order_item['product']->product_photo)); ?>");background-size: contain;background-repeat: no-repeat;background-position: center'>

                                                                        </span>
                                                                        <span class="tooltip-content clearfix">
                                                                            <img
                                                                                src="<?php echo e(asset('storage/product/' . $order_item['product']->product_photo)); ?>">
                                                                        </span>
                                                                    </span>
                                                                </td>
                                                                <td><?php echo e($order_item['product']->product_name_ar); ?></td>
                                                                <td><?php echo e($order_item->qty); ?></td>
                                                                <td>
                                                                    <?php if(!empty($order_item['unit']->unit_name)): ?>
                                                                        <?php echo e($order_item['unit']->unit_name); ?>

                                                                    <?php endif; ?>
                                                                </td>
                                                                <td>
                                                                    <input style="background-color:#fff4c9"
                                                                        onchange="AddOrUpdatePrice(<?php echo e($key['supplier']->id); ?>,<?php echo e($order_item->product_id); ?>,this.value)"
                                                                        value="<?php echo e(\App\Models\PriceOfferItemsModel::where('order_id', $key->order_id)->where('product_id', $order_item->product_id)->where('supplier_id', $key['supplier']->id)->value('price')); ?>"
                                                                        type="text" class="form-control text-center">
                                                                </td>
                                                                <td>
                                                                    <input
                                                                        onchange="add_or_update_bonus(<?php echo e($key['supplier']->id); ?>,<?php echo e($order_item->product_id); ?>,this.value)"
                                                                        class="form-control text-center" type="text"
                                                                        value="<?php echo e(\App\Models\PriceOfferItemsModel::where('order_id', $key->order_id)->where('product_id', $order_item->product_id)->where('supplier_id', $key['supplier']->id)->value('bonus')); ?>">
                                                                </td>
                                                                <td>
                                                                    <input
                                                                        onchange="add_or_update_discount(<?php echo e($key['supplier']->id); ?>,<?php echo e($order_item->product_id); ?>,this.value)"
                                                                        class="form-control text-center" type="text"
                                                                        value="<?php echo e(\App\Models\PriceOfferItemsModel::where('order_id', $key->order_id)->where('product_id', $order_item->product_id)->where('supplier_id', $key['supplier']->id)->value('discount_present')); ?>">
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-md-2" align="center">
                                        <div class="mt-2">
                                            <label for="">العملة</label>
                                            <select onchange="updateCurrency(<?php echo e($key['supplier']->id); ?>,this.value)"
                                                class="form-control" name="" id="">
                                                <?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php if($cur->id == $key->currency_id): ?> selected <?php endif; ?>
                                                        value="<?php echo e($cur->id); ?>"><?php echo e($cur->currency_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="div">
                                            <b style="font-size: 12px">بواسطة <span><?php echo e($key['user']->name); ?></span></b>
                                        </div>
                                        <?php echo e($key->created_at); ?>

                                        <div>
                                            <a href="<?php echo e(route('procurement_officer.orders.price_offer.edit_price_offer', ['id' => $key->id])); ?>"
                                                class="btn btn-success btn-sm">تعديل</a>
                                            <a href="<?php echo e(route('procurement_officer.orders.price_offer.delete_offer_price', ['id' => $key->id])); ?>"
                                                class="btn btn-danger btn-sm">حذف</a>
                                        </div>
                                        <div class="mt-2">
                                            <?php if(!empty($key->attachment)): ?>
                                                <a type="text"
                                                    href="<?php echo e(asset('storage/attachment/' . $key->attachment)); ?>"
                                                    download="attachment" class="btn btn-primary btn-sm"><span
                                                        class="fa fa-download"></span></a>
                                                <button
                                                    onclick="viewAttachment('<?php echo e(asset('storage/attachment/' . $key->attachment)); ?>')"
                                                    href="" class="btn btn-success btn-sm" data-toggle="modal"
                                                    data-target="#modal-lg-view_attachment"><span
                                                        class="fa fa-search"></span></button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <button onclick="getOrderIdAndSupplierId(<?php echo e($order->id); ?>,<?php echo e($key->supplier_id); ?>)"
                                    class="btn btn-success btn-sm" data-toggle="modal"
                                    data-target="#modal-lg-import">استيراد من اكسيل
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal-lg-offer_price">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form action="<?php echo e(route('procurement_officer.orders.price_offer.create_price_offer')); ?>" method="post"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h4 class="modal-title">اضافة عرض سعر</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div hidden class="form-group">
                                    <label for="">رقم الطلبية</label>
                                    <input type="text" value="<?php echo e($order->id); ?>" name="order_id" readonly
                                        class="form-control">
                                </div>
                            </div>
                            <div hidden class="col-md-6">
                                <div class="form-group">
                                    <label for="">اسم المستخدم</label>
                                    <input type="text" value="<?php echo e(auth()->user()->name); ?>" readonly
                                        class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">المورد</label>
                                    <select class="form-control select2bs4" data-select2-id="3" tabindex="-1"
                                        tabindex="-1" name="supplier_id" id="">
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key->id); ?>"><?php echo e($key->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">ارفاق ملف</label>
                                    <input name="attachment" type="file" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">ملاحظات</label>
                                    <textarea class="form-control" name="notes" id="" cols="30" rows="2"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">اغلاق</button>
                        <button type="submit" class="btn btn-primary">حفظ</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal-lg-import">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form action="<?php echo e(route('procurement_officer.orders.price_offer.importExcel')); ?>" method="post"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="order_id" id="order_id">
                    <input type="hidden" name="supplier_id" id="supplier_id">
                    <div class="modal-header">
                        <h4 class="modal-title">استيراد من اكسيل</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">ارفاق ملف</label>
                                    <input name="file" type="file" class="form-control">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">اغلاق</button>
                        <button type="submit" class="btn btn-primary">حفظ</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="text-center">
        <p>تم انشاء هذه الطلبية بواسطة <span class="text-danger text-bold"><?php echo e($order['user']->name ?? ''); ?></span> ويتم
            متابعتها بواسطة <span class="text-danger text-bold"><?php echo e($order['to_user']->name ?? ''); ?></span></p>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/jszip/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/pdfmake/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/pdfmake/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.colVis.min.js')); ?>"></script>


    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.full.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/toastr/toastr.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/dist/js/demo.js')); ?>"></script>

    <script>
        function getOrderIdAndSupplierId(order_id, supplier_id) {
            document.getElementById('order_id').value = order_id;
            document.getElementById('supplier_id').value = supplier_id;
        }
    </script>

    <script>
        function AddOrUpdatePrice(supplier_id, product_id, price) {
            var csrfToken = $('meta[name="csrf-token"]').attr('content');
            var headers = {
                "X-CSRF-Token": csrfToken
            };
            $.ajax({
                url: '<?php echo e(url('users/procurement_officer/orders/price_offer_items/create')); ?>',
                method: 'post',
                headers: headers,
                data: {
                    'order_id': <?php echo e($order->id); ?>,
                    'supplier_id': supplier_id,
                    'product_id': product_id,
                    'price': price
                },
                success: function(data) {
                    console.log(data);
                    toastr.success('تم تعديل السعر بنجاح')
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.log(textStatus);
                    alert('error');
                }
            });
        }

        function updateCurrency(supplier_id, currency_id) {
            var csrfToken = $('meta[name="csrf-token"]').attr('content');
            var headers = {
                "X-CSRF-Token": csrfToken
            };
            $.ajax({
                url: '<?php echo e(route('procurement_officer.orders.price_offer.updateCurrency')); ?>',
                method: 'post',
                headers: headers,
                data: {
                    'order_id': <?php echo e($order->id); ?>,
                    'supplier_id': supplier_id,
                    'currency_id': currency_id
                },
                success: function(data) {
                    console.log(data);
                    toastr.success('تم تعديل العملة بنجاح')
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.log(textStatus);
                    alert('error');
                }
            });
        }

        function add_or_update_bonus(supplier_id, product_id, bonus) {
            var csrfToken = $('meta[name="csrf-token"]').attr('content');
            var headers = {
                "X-CSRF-Token": csrfToken
            };
            $.ajax({
                url: '<?php echo e(route('procurement_officer.orders.price_offer_items.add_or_update_bonus')); ?>',
                method: 'post',
                headers: headers,
                data: {
                    'order_id': <?php echo e($order->id); ?>,
                    'supplier_id': supplier_id,
                    'product_id': product_id,
                    'bonus': bonus
                },
                success: function(data) {
                    console.log(data);
                    toastr.success('تم تعديل العلاوة بنجاح')
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.log(errorThrown);
                }
            });
        }

        function add_or_update_discount(supplier_id, product_id, discount_present) {
            var csrfToken = $('meta[name="csrf-token"]').attr('content');
            var headers = {
                "X-CSRF-Token": csrfToken
            };
            $.ajax({
                url: '<?php echo e(route('procurement_officer.orders.price_offer_items.add_or_update_discount')); ?>',
                method: 'post',
                headers: headers,
                data: {
                    'order_id': <?php echo e($order->id); ?>,
                    'supplier_id': supplier_id,
                    'product_id': product_id,
                    'discount_present': discount_present
                },
                success: function(data) {
                    console.log(data);
                    toastr.success('تم تعديل الخصم بنجاح')
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.log(errorThrown);
                }
            });
        }
    </script>

    <script>
        $(function() {
            $("#example1").DataTable({
                "responsive": true,
                "lengthChange": false,
                "autoWidth": false,
                // "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        });
    </script>

    <script>
        $(function() {
            var Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000
            });

            $('.swalDefaultSuccess').click(function() {
                Toast.fire({
                    icon: 'success',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.swalDefaultInfo').click(function() {
                Toast.fire({
                    icon: 'info',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.swalDefaultError').click(function() {
                Toast.fire({
                    icon: 'error',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.swalDefaultWarning').click(function() {
                Toast.fire({
                    icon: 'warning',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.swalDefaultQuestion').click(function() {
                Toast.fire({
                    icon: 'question',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });

            $('.toastrDefaultSuccess').click(function() {
                toastr.success('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
            });
            $('.toastrDefaultInfo').click(function() {
                toastr.info('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
            });
            $('.toastrDefaultError').click(function() {
                toastr.error('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
            });
            $('.toastrDefaultWarning').click(function() {
                toastr.warning('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
            });

            $('.toastsDefaultDefault').click(function() {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultTopLeft').click(function() {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    position: 'topLeft',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultBottomRight').click(function() {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    position: 'bottomRight',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultBottomLeft').click(function() {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    position: 'bottomLeft',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultAutohide').click(function() {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    autohide: true,
                    delay: 750,
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultNotFixed').click(function() {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    fixed: false,
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultFull').click(function() {
                $(document).Toasts('create', {
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    icon: 'fas fa-envelope fa-lg',
                })
            });
            $('.toastsDefaultFullImage').click(function() {
                $(document).Toasts('create', {
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    image: '../../dist/img/user3-128x128.jpg',
                    imageAlt: 'User Picture',
                })
            });
            $('.toastsDefaultSuccess').click(function() {
                $(document).Toasts('create', {
                    class: 'bg-success',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultInfo').click(function() {
                $(document).Toasts('create', {
                    class: 'bg-info',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultWarning').click(function() {
                $(document).Toasts('create', {
                    class: 'bg-warning',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultDanger').click(function() {
                $(document).Toasts('create', {
                    class: 'bg-danger',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultMaroon').click(function() {
                $(document).Toasts('create', {
                    class: 'bg-maroon',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
        });
    </script>

    <script>
        $(function() {
            //Initialize Select2 Elements
            $('.select2').select2()

            //Initialize Select2 Elements
            $('.select2bs4').select2({
                theme: 'bootstrap4'
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/orders/procurement_officer/price_offer/index.blade.php ENDPATH**/ ?>