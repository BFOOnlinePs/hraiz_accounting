<table id="example1" class="table table-bordered table-striped dataTable dtr-inline"
       aria-describedby="example1_info">
    <thead>
    <tr>
        <th>المنتج</th>
        <th>اسم خط الانتاج</th>
        <th>ملاحظات</th>
        <th>العمليات</th>
    </tr>
    </thead>
    <tbody>
    <?php if($data->isEmpty()): ?>
        <tr>
            <td colspan="4" class="text-center">لا توجد بيانات</td>
        </tr>
    <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="<?php if($key->status == 'incomplete'): ?> bg-danger <?php endif; ?>">
                <td><?php echo e($key->product->product_name_ar); ?></td>
                <td><?php echo e($key->production_name); ?></td>
                <td>
                    <?php echo e($key->production_notes); ?>

                </td>
                <td>
                    <a class="btn btn-success btn-sm" href="<?php echo e(route('production.edit',['id'=>$key->id])); ?>"><span class="fa fa-edit"></span></a>
                    <a class="btn btn-dark btn-sm" href="<?php echo e(route('production.production_inputs.index',['id'=>$key->id])); ?>"><span class="fa fa-search"></span></a>
                    <a onclick="return confirm('هل انت متاكد من حذف البيانات ؟')" class="btn btn-danger btn-sm" href="<?php echo e(route('production.delete',['id'=>$key->id])); ?>"><span class="fa fa-trash"></span></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </tbody>
</table>
<?php echo e($data->links()); ?>

<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/production/production_line/ajax/production_lines_table.blade.php ENDPATH**/ ?>