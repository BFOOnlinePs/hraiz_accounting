<table style="width: 100%" class="table table-bordered">
    <thead>
        <tr>
            <th class="sorting sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"
                aria-sort="ascending">#
            </th>
            <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1">الاسم
            </th>
            <th>
                رقم الهاتف
            </th>
            <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1">البريد الالكتروني
            </th>
            <th>متابعة بواسطة</th>
            <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1">حالة الحساب
            </th>
            <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1">العمليات
            </th>
        </tr>
    </thead>
    <tbody>
        <?php if($data->isEmpty()): ?>
            <tr>
                <td colspan="7" class="text-center">لا توجد نتائج</td>
            </tr>
        <?php endif; ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->index + 1); ?></td>
                <td><?php echo e($key->name); ?></td>
                <td><?php echo e($key->user_phone1); ?></td>
                <td><?php echo e($key->email); ?></td>
                <td>
                    <select id="follow_by_<?php echo e($key->id); ?>" onchange="update_follow_by('<?php echo e($key->id); ?>')" style="width: 100%" class="form-control select2bs4" multiple="multiple">
                        <?php
                            $followByArray = json_decode(($key['follow_by']));
                        ?>
                        <?php $__currentLoopData = $officer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php if(!empty($key['follow_by'])): ?> <?php echo e(in_array($item->id, $followByArray) ? 'selected' : ''); ?> <?php endif; ?>>
                                <?php echo e($item->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </td>
                <td>
                    <div class="custom-control custom-switch custom-switch-off-danger custom-switch-on-success">
                        <input <?php if($key->user_status == 1): ?> checked <?php endif; ?>
                            onchange="updateStatus(<?php echo e($key->id); ?>)" type="checkbox" class="custom-control-input"
                            id="customSwitch<?php echo e($key->id); ?>">
                        <label class="custom-control-label" for="customSwitch<?php echo e($key->id); ?>"></label>
                    </div>
                </td>
                <td>
                    <a class="btn btn-success btn-sm" href="<?php echo e(route('users.supplier.edit', ['id' => $key->id])); ?>"><span
                            class="fa fa-edit"></span></a>
                    <a class="btn btn-dark btn-sm" href="<?php echo e(route('users.supplier.details', ['id' => $key->id])); ?>"><span
                            class="fa fa-search"></span></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/users/supplier/ajax/supplier_table.blade.php ENDPATH**/ ?>