<?php $__env->startSection('title'); ?>
    أنواع الإجازات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title'); ?>
    أنواع الإجازات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_link'); ?>
    الرئيسية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title_link'); ?>
أنواع الإجازات

<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/toastr/toastr.min.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.messge_alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.messge_alert.fail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <button type="button" class="btn btn-primary mb-2" data-toggle="modal" data-target="#modal-default">إضافة نوع إجازة</button>
    <div class="card">
        <div class="card-header">
            <h3 class="text-center">أنواع الإجازات</h3>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th class="sorting sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-sort="ascending">#
                        </th>
                        <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1">نوع الإجازة</th>
                        <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1">العمليات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($vacations_types->isEmpty()): ?>
                        <tr>
                            <td colspan="3" class="text-center" style="background-color: rgba(128, 128, 128, 0.274)">لا توجد نتائج</td>
                        </tr>
                    <?php endif; ?>
                    <?php $__currentLoopData = $vacations_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td><?php echo e($key->type_name); ?></td>
                            <td>
                                <button class="btn btn-success btn-sm" onclick="edit_vacations_types(<?php echo e($key->id); ?> , '<?php echo e($key->type_name); ?>')"><span class="fa fa-edit pt-1"></span></button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo $__env->make('admin.setting.vacations_types.modals.addVacationsTypesModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin.setting.vacations_types.modals.editVacationsTypesModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/plugins/toastr/toastr.min.js')); ?>"></script>
    <script>
        function edit_vacations_types(id , type_name)
        {
            document.getElementById('id_editVacationsTypesModal').value = id;
            document.getElementById('type_name_editVacationsTypesModal').value = type_name;
            $('#editVacationsTypesModal').modal('show');
        }
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/setting/vacations_types/index.blade.php ENDPATH**/ ?>