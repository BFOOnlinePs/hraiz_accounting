<table class="table table-sm table-bordered table-hover">
    <thead>
        <tr>
            <th></th>
            <th>اسم الصنف</th>
        </tr>
    </thead>
    <tbody>
    <?php if($data->isEmpty()): ?>
        <tr>
            <td colspan="2" class="text-center">لا توجد نتائج</td>
        </tr>
    <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <input type="checkbox" onchange="create_assembled_product_ajax(<?php echo e($key->id); ?>)">
                </td>
                <td><?php echo e($key->product_name_ar); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </tbody>
</table>
<?php echo e($data->links()); ?>

<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/product/ajax/search_assembled_product_ajax.blade.php ENDPATH**/ ?>