<table class="table table-sm table-hover table-bordered">
    <thead>
    <tr>
        <th>اسم المدخل</th>
        <th>العدد</th>
        <th>تكلفة الوحدة</th>
        <th>المجموع</th>
        <th>الوزن</th>
        <th>الطول</th>
        <th>الملاحظات</th>
        <th>العمليات</th>
    </tr>
    </thead>
    <tbody>
    <?php if($data->isEmpty()): ?>
        <tr>
            <td colspan="10" class="text-center">لا توجد بيانات</td>
        </tr>
    <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href="<?php echo e(route('product.details',['id'=>$key->id])); ?>"><?php echo e($key->production_input_name); ?></a></td>
                <td>
                    <input type="text" onchange="update_product_line_inputs_ajax(<?php echo e($key->id); ?>,'qty',this.value)" class="form-control" value="<?php echo e($key->qty); ?>">
                </td>
                <td>
                    <?php if($key->product_id == -1): ?>
                        <input type="text" onchange="update_product_line_inputs_ajax(<?php echo e($key->id); ?>,'estimated_cost',this.value)" class="form-control" value="<?php echo e($key->estimated_cost); ?>">
                    <?php else: ?>
                        <input type="text" readonly class="form-control" value="<?php echo e($key->estimated_cost); ?>">
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($key->product_id == -1): ?>
                        <input type="text" readonly class="form-control" value="<?php echo e($key->estimated_cost * $key->qty); ?>">
                    <?php else: ?>
                        <input type="text" readonly class="form-control" value="<?php echo e($key->product->cost_price * $key->qty); ?>">
                    <?php endif; ?>
                </td>
                <td>
                    <input type="text" readonly class="form-control" value="<?php echo e($key->product->weight??''); ?>">
                </td>
                <td>
                    <input type="text" readonly class="form-control" value="<?php echo e($key->product->height??''); ?>">
                </td>
                <td>
                    <input type="text" onchange="update_product_line_inputs_ajax(<?php echo e($key->id); ?>,'production_input_notes',this.value)" class="form-control" value="<?php echo e($key->production_input_notes); ?>">
                </td>
                <td>
                    

                    <button onclick="delete_production_input_ajax(<?php echo e($key->id); ?>)" class="btn btn-danger btn-sm"><span class="fa fa-trash"></span></button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </tbody>
</table>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/production/production_line/ajax/production_inputs_table.blade.php ENDPATH**/ ?>