<?php $__env->startSection('title'); ?>
    تفاصيل السكرتيريا
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title'); ?>
    تفاصيل السكرتيريا
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_link'); ?>
    السكرتيريا
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title_link'); ?>
    تفاصيل السكرتيريا
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/toastr/toastr.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fullcalendar/main.css')); ?>">


    <?php echo $__env->make('admin.messge_alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.messge_alert.fail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        
        
        
        <div class="card-body">

            <style>
                .active {
                    color: black !important;
                }

                .nav-link {
                    text-decoration: none;
                }
            </style>


            
            <div class="row">
                <div class="col-md-12">
                    <div class="card-body">
                        <h3 class="pb-3"><?php echo e($data->name); ?></h3>
                        <ul class="nav nav-tabs alert-info text-white" style="" id="custom-content-below-tab"
                            role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active text-white" id="custom-content-below-home-tab"
                                   data-toggle="pill"
                                   href="#custom-content-below-home" role="tab"
                                   aria-controls="custom-content-below-home" aria-selected="true">المعلومات العامة</a>
                            </li>















                            <li class="nav-item">
                                <a class="nav-link text-white" id="custom-content-below-calender-tab" data-toggle="pill"
                                   href="#custom-content-below-calender" role="tab"
                                   aria-controls="custom-content-below-calender" aria-selected="false">تقويم</a>
                            </li>





                            <li class="nav-item">
                                <a class="nav-link text-white" id="custom-content-below-settings-tab" data-toggle="pill"
                                   href="#custom-content-below-settings" role="tab"
                                   aria-controls="custom-content-below-settings" aria-selected="false">سجل المتابعة</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link text-white" id="subscriptions-tab" data-toggle="pill"
                                   href="#subscriptions" role="tab"
                                   aria-controls="subscriptions" aria-selected="false">الاشتراكات</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link text-white" id="pages-tab" data-toggle="pill"
                                   href="#pages" role="tab"
                                   aria-controls="pages" aria-selected="false">الصفحات</a>
                            </li>





                        </ul>
                        <div class="tab-content" id="custom-content-below-tabContent">
                            <div class="tab-pane fade active show" id="custom-content-below-home" role="tabpanel"
                                 aria-labelledby="custom-content-below-home-tab">
                                <div class="p-2">
                                    <div class="row">
                                        <div class="col-md-8 p-5">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="">الاسم :</label>
                                                        <input onchange="update_user_ajax('name',this.value)" class="form-control" value="<?php echo e($data->name); ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="">الايميل :</label>
                                                        <input onchange="update_user_ajax('email',this.value)" class="form-control" value="<?php echo e($data->email); ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="">رقم الهاتف الاول :</label>
                                                        <input onchange="update_user_ajax('user_phone1',this.value)" class="form-control" value="<?php echo e($data->user_phone1); ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="">رقم الهاتف الثاني :</label>
                                                        <input onchange="update_user_ajax('user_phone2',this.value)" class="form-control" value="<?php echo e(empty($data->user_phone2) ? 'لا يوجد' : $data->user_phone2); ?>">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="">ملاحظات : </label>
                                                        <textarea onchange="update_user_ajax('user_notes',this.value)" class="form-control" name="" id="" cols="30"
                                                                  rows="3"><?php echo e($data->user_notes); ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="">العنوان :</label>
                                                        <textarea onchange="update_user_ajax('user_address',this.value)" class="form-control" name="" id="" cols="30"
                                                                  rows="3"><?php echo e($data->user_address); ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <div class="custom-control custom-switch custom-switch-off-danger custom-switch-on-success">
                                                            <input onchange="update_user_ajax('user_status',(this.checked) ?1:0)" <?php if($data->user_status == 1): ?> checked <?php endif; ?> type="checkbox" class="custom-control-input" id="customSwitch3">
                                                            <label class="custom-control-label" for="customSwitch3">حالة المستخدم</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                
                                                
                                                
                                                
                                                
                                            </div>
                                        </div>
                                        <div class="col-md-4 pt-5 text-center">
                                            <div class="form-group text-center">
                                                <?php if(empty($data->user_photo)): ?>
                                                    <img id="image_preview_container" width="150" src="<?php echo e(asset('storage/user_photo/'.$data->user_photo)); ?>" alt="">
                                                <?php else: ?>
                                                    <img id="image_preview_container" width="150" src="<?php echo e(asset('storage/user_photo/'.$data->user_photo)); ?>" alt="">
                                                <?php endif; ?>
                                            </div>
                                            <div>
                                                <h4 class="text-center"><?php echo e($data->name); ?></h4>
                                                <hr>
                                                <form method="POST" enctype="multipart/form-data" id="upload_image_form">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <input class="form-control" type="file" name="image" placeholder="Choose image" id="image">
                                                                <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <button type="submit" class="btn btn-primary">رفع الصورة</button>
                                                        </div>
                                                    </div>
                                                </form>
                                                
                                                
                                            </div>
                                        </div>
                                    </div>                                </div>
                            </div>
                            <div class="tab-pane fade" id="custom-content-below-profile" role="tabpanel"
                                 aria-labelledby="custom-content-below-profile-tab">
                                <div class="row">
                                    <div class="col-md-8 p-5">
                                        <div class="form-group">
                                            <label for="">اسم المستفيد :</label>
                                            <input class="form-control" type="text" name="account_owner"
                                                   placeholder="اسم جهة الحساب">
                                        </div>
                                        <div class="form-group">
                                            <label>رقم حساب البنك :</label>
                                            <span
                                                class="form-control"><?php echo e($data->user_account_number); ?></span>
                                        </div>
                                        <div class="form-group">
                                            <label>اسم البنك :</label>
                                            <span
                                                class="form-control"><?php echo e($data->user_bank_name); ?></span>
                                        </div>
                                        <div class="form-group">
                                            <label>عنوان البنك :</label>
                                            <textarea disabled class="form-control" name="" id=""
                                                      cols="30"
                                                      rows="3"><?php echo e($data->user_bank_address); ?></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label>Swift code :</label>
                                            <span
                                                class="form-control"><?php echo e($data->user_swift_code); ?></span>
                                        </div>
                                        <div class="form-group">
                                            <label>IBAN Number :</label>
                                            <span
                                                class="form-control"><?php echo e($data->user_iban_number); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="text-center pt-5">
                                            <i class="fa-solid fa-building-columns text-info"
                                               style="font-size: 180px"></i>
                                            <br><br>
                                            <h4>معلومات البنك</h4>
                                            <hr>
                                            <p>يحتوي هذا القسم على جميع معلومات البنك الذي يتم التعامل معه بواسطة هذا
                                                المورد</p>
                                            <a href="" class="btn btn-info">تعديل بيانات البنك</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="custom-content-below-messages" role="tabpanel"
                                 aria-labelledby="custom-content-below-messages-tab">
                                <div class="row">
                                    <div class="col-md-8 pt-5">
                                        <label for="">جهة التواصل</label>
                                        <table style="font-size: 14px;border: solid 1px black;width: 100%"
                                               id="contact_person_table"
                                               class="table-hover table-bordered text-center">
                                            <thead>
                                            <tr>
                                                <th>الصورة</th>
                                                <th>الاسم</th>
                                                <th>الهاتف</th>
                                                <th>الايميل</th>
                                                <th>الوتس اب</th>
                                                <th>الوي شات</th>
                                                <th>العنوان</th>
                                                <th>العمليات</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $company_contact_person; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr id="delete_<?php echo e($key->id); ?>">
                                                    <td><img style="width: 30px;height: 30px" class="p-1"
                                                             src="<?php echo e(asset('storage/user_photo/avatar.png')); ?>" alt="">
                                                    </td>
                                                    <td><?php echo e($key->contact_name); ?></td>
                                                    <td><?php echo e($key->mobile_number); ?></td>
                                                    <td><?php echo e($key->email); ?></td>
                                                    <td><?php echo e($key->whats_app_number); ?></td>
                                                    <td><?php echo e($key->wechat_number); ?></td>
                                                    <td><?php echo e($key->address); ?></td>
                                                    <td>
                                                        <button onclick="deleteMessage(<?php echo e($key->id); ?>)"
                                                                class="btn btn-sm btn-danger">X
                                                        </button>
                                                    </td>

                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>

                                    </div>
                                    <div class="col-md-4">
                                        <div class="text-center pt-5">
                                            <i class="fa-solid fa-address-card text-info" style="font-size: 180px"></i>
                                            <br><br>
                                            <h4>معلومات جهات الاتصال</h4>
                                            <hr>
                                            <p>يحتوي هذا القسم على معلومات جهات الاتصال التي يتم التواصل من خلالها مع
                                                هذا المورد</p>
                                            <button type="button" class="btn btn-info" data-toggle="modal"
                                                    data-target="#modal-default">
                                                اضافة جديد
                                            </button>
                                            <div class="modal fade" id="modal-default">
                                                <div class="modal-dialog">
                                                    <form action="<?php echo e(route('company_contact_person.supplier.create')); ?>"
                                                          method="post" enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="text" hidden name="company_id"
                                                               value="<?php echo e($data->id); ?>">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h4 class="modal-title">اضافة جهة تواصل جديدة</h4>
                                                                <button type="button" class="close" data-dismiss="modal"
                                                                        aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="form-group">
                                                                    <label for="">الاسم</label>
                                                                    <input name="contact_name" class="form-control"
                                                                           type="text"
                                                                           placeholder="الاسم">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="">رقم الهاتف</label>
                                                                    <input name="mobile_number" class="form-control"
                                                                           type="text"
                                                                           placeholder="رقم الهاتف">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="">البريد الالكتروني</label>
                                                                    <input name="email" class="form-control" type="text"
                                                                           placeholder="البريد الالكتروني">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="">رقم WhatsApp</label>
                                                                    <input name="whats_app_number" class="form-control"
                                                                           type="text"
                                                                           placeholder="رقم الواتس اب">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="">رقم WeChat</label>
                                                                    <input name="wechat_number" class="form-control"
                                                                           type="text"
                                                                           placeholder="رقم وي شات">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="">العنوان</label>
                                                                    <textarea class="form-control" name="address" id=""
                                                                              cols="30"
                                                                              rows="2" placeholder="العنوان"></textarea>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="">الصورة</label>
                                                                    <div class="custom-file">
                                                                        <input name="photo" type="file"
                                                                               class="custom-file-input"
                                                                               id="customFile">
                                                                        <label class="custom-file-label"
                                                                               for="customFile">تحميل
                                                                            صورة</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer justify-content-between">
                                                                <button type="button" class="btn btn-danger"
                                                                        data-dismiss="modal">اغلاق
                                                                </button>
                                                                <button type="submit" class="btn btn-primary">حفظ
                                                                </button>
                                                            </div>

                                                        </div>
                                                    </form>

                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="custom-content-below-settings" role="tabpanel"
                                 aria-labelledby="custom-content-below-settings-tab">
                                <div class="p-2">
                                    <h5 class="text-center">قريبا ..</h5>






















































                                </div>
                            </div>
                            <div class="tab-pane fade" id="custom-content-below-calender" role="tabpanel"
                                 aria-labelledby="custom-content-below-calender-tab">
                                <div class="p-2">
                                    <div class="container">
                                        <div class="response"></div>
                                    </div>
                            </div>
                        </div>
                            <div class="tab-pane fade" id="subscriptions" role="tabpanel"
                                 aria-labelledby="subscriptions-tab">
                                <div class="p-2">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <button class="btn btn-dark">اضافة اشتراك</button>
                                        </div>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-md-12">
                                            <div class="table-responsive">
                                                <table class="table table-sm table-bordered">
                                                    <thead>
                                                    <tr>
                                                        <th>من تاريخ</th>
                                                        <th>الى تاريخ</th>
                                                        <th>ملاحظات</th>
                                                        <th>حالة الاشتراك</th>
                                                        <th>تمت الاضافة بواسطة</th>
                                                        <th>تمت الاضافة بتاريخ</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <tr>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="pages" role="tabpanel"
                                 aria-labelledby="pages-tab">
                                <div class="p-2">
                                    pages
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/jszip/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/pdfmake/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/pdfmake/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.colVis.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/jquery/jquery.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/toastr/toastr.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/jquery/jquery.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/fullcalendar/main.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/dist/js/demo.js')); ?>"></script>



    <script>
        $(function () {
            $("#example1").DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                // "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        });
    </script>


    <script>
        function add_contact_person() {
            var contact_person_table = document.getElementById('contact_person_table');
            var count = <?php echo e(\App\Models\CompanyContactPersonModel::count()); ?>;
            if (contact_person_table.rows.length == count + 1) {
                var new_row = contact_person_table.insertRow();
                var cell1 = new_row.insertCell();
                var cell2 = new_row.insertCell();
                var cell3 = new_row.insertCell();
                var cell4 = new_row.insertCell();
                cell1.innerText = '2';
                cell2.innerText = 'test2';
                cell3.innerHTML = '<button class="btn btn-sm btn-dark">تفاصيل</button>';
                cell4.innerHTML = '<button class="btn btn-sm btn-danger">X</button>';
            } else {
                alert('يرجى تعبئة الحقل الفارغ')
            }
            console.log(contact_person_table.rows.length);
            // console.log(count);

        }

        function deleteMessage(id) {
            var csrfToken = $('meta[name="csrf-token"]').attr('content');
            var headers = {
                "X-CSRF-Token": csrfToken
            };
            var confirmationMessage = "هل انت متاكد انك تريد حذف البيانات ؟";
            var userConfirmed = window.confirm(confirmationMessage);
            if (userConfirmed) {
                $.ajax({
                    url: '<?php echo e(url('company_contact_person/delete')); ?>' + '/' + id,
                    method: 'get',
                    headers: headers,
                    success: function (data) {
                        document.getElementById('delete_' + id).remove();
                        toastr.success('تم حذف البيانات بنجاح')
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        alert('error');
                    }
                });
            }
        }
        function update_user_ajax(data_type,value)
        {
            let user_id = <?php echo e($data->id); ?>;
            var csrfToken = $('meta[name="csrf-token"]').attr('content');
            var headers = {
                "X-CSRF-Token": csrfToken
            };
            $.ajax({
                url: "<?php echo e(route('users.update_user_ajax')); ?>",
                method: 'post',

                headers: headers,
                data: {
                    'data_type':data_type,
                    'value': value ,
                    'id':user_id
                },
                success: function(data) {
                    if(data.success == 'true'){
                        toastr.success(data.message)
                    }
                    else{
                        toastr.error(data.message)
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    alert(jqXHR.responseText);
                    // toastr.error(jqXHR.message)
                }
            });
        }

        $(document).ready(function (e) {
            $('#image').change(function (){
                let reader = new FileReader();
                reader.onload = (e) => {
                    $('#image_preview_container').attr('src',e.target.result);
                }
                reader.readAsDataURL(this.files[0]);
            });
            $('#upload_image_form').submit(function (e) {
                e.preventDefault();
                let user_id = <?php echo e($data->id); ?>;
                var formData = new FormData(this);
                formData.append('id',user_id);
                $.ajax({
                    type: 'POST',
                    url: "<?php echo e(route('users.upload_image')); ?>",
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: (data) => {
                        toastr.success(data.message);
                        this.reset();
                    },
                    error: function(jqXHR) {
                        console.log(jqXHR.responseText);
                    }
                });
            })
        })

    </script>




    <script>
        $(function () {
        $('#calendar').fullCalendar({
            header: {
                left: 'prev,next today',
                center: 'addEventButton',
                right: 'month,agendaWeek,agendaDay,listWeek'
            },
            defaultDate: '2018-11-16',
            navLinks: true,
            editable: true,
            eventLimit: true,
            selectable: true,
            events: [{
                title: 'Simple static event',
                start: '2018-11-16',
                description: 'Super cool event'
            },

            ],
            select: function (startDate, endDate) {
                var dateStart = moment(startDate);
                var dateEnd = moment(endDate);

                if (dateStart.isValid() && dateEnd.isValid()) {
                    $('#calendar-5').fullCalendar('renderEvent', {
                        title: 'Long event',
                        start: dateStart,
                        end: dateEnd,
                        allDay: true
                    });
                }
            }
        });
    });

</script>






<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/users/clients/details.blade.php ENDPATH**/ ?>