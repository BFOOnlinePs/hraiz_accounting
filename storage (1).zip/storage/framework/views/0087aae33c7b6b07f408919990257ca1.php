<?php $__env->startSection('title'); ?>
    الموظفين
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title'); ?>
    الرواتب
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_link'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title_link'); ?>
    الرواتب
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.messge_alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.messge_alert.fail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <button onclick="showCreateSalaryModal()" class="btn btn-dark mb-2">إضافة راتب</button>
    <div class="card">
        <div class="card-header">
            <h3 class="text-center">قائمة الرواتب</h3>
        </div>
        <div class="card-body">
            <div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <!-- <input type="text" onkeyup="employee_table()" class="form-control" id="search" placeholder="بحث"> -->
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <table class="table table-hover table-bordered">
                            <thead>
                                <tr>
                                    <th>اسم الموظف</th>
                                    <th>القيمة</th>
                                    <th>الشهر</th>
                                    <th>السنة</th>
                                    <th>عدد الايام</th>
                                    <th>تاريخ الاضافة</th>
                                    <th>الحالة</th>
                                    <th>العمليات</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if($data->isEmpty()): ?>
                                <tr>
                                    <td colspan="7" class="text-center">لا توجد بيانات</td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key->employee->name); ?></td>
                                        <td><?php echo e($key->salary_value); ?></td>
                                        <td><?php echo e($key->month); ?></td>
                                        <td><?php echo e($key->year); ?></td>
                                        <td><?php echo e($key->days); ?></td>
                                        <td><?php echo e($key->insert_at); ?></td>
                                        <td><?php echo e($key->status); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('hr.salaries.edit',['id'=>$key->id])); ?>" class="btn btn-success btn-sm"><span class="fa fa-edit"></span></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.hr.salaries.modals.salaryCreate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.full.min.js')); ?>"></script>

    <script>
        function showCreateSalaryModal()
        {
            $('#create_salary_modal').modal('show');
        }
    </script>

    <script>
        $(function () {
            $('.select2bs4').select2({
                theme: 'bootstrap4'
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/hr/salaries/index.blade.php ENDPATH**/ ?>