<table style="width: 100%" class="table-sm  table-bordered">
    <thead>
    <tr>
        <th class="">باركود</th>
        <th>اسم الصنف المخرج</th>
        <th>عدد وحدات الانتاج</th>
        <th class="text-center bg-warning">تفاصيل تكاليف الانتاج</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td><?php echo e($production_lines->product->barcode); ?></td>
        <td><?php echo e($production_lines->product->product_name_ar); ?></td>
        <td><?php echo e($production_lines->production_output_count); ?></td>
        <td>
            <table style="width: 100%" class="table-sm ">
                <thead>
                <tr class="bg-secondary">
                    <th>اسم المدخل</th>
                    <th>العدد</th>
                    <th>التكلفة</th>
                    <th>المجموع</th>
                    <th>وزن بروفيل</th>
                    <th>وزن زاوية</th>
                    <th>تكلفة الزاوية</th>
                </tr>
                </thead>
                <tbody>
                <?php if($data->isEmpty()): ?>
                    <tr>
                        <td colspan="10" class="text-center">لا توجد بيانات</td>
                    </tr>
                <?php else: ?>
                    <?php
                        $total_sum = 0;
                    ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($key->production_input_name); ?></td>
                            <td>
                                <?php echo e($key->qty); ?>

                            </td>
                            <td>
                                <?php if($key->product_id == -1): ?>
                                    <?php echo e($key->estimated_cost); ?>

                                <?php else: ?>
                                    <?php echo e($key->product->cost_price); ?>

                                <?php endif; ?>
                            </td>
                            <td><?php echo e(($key->qty) * (($key->product_id == -1)?$key->estimated_cost:$key->product->cost_price)); ?></td>
                            <td>
                                <?php echo e($key->product->weight??''); ?>

                            </td>
                            <td class="bg-success">
                                <?php if(!empty($key->product->weight) && !empty($production_lines->production_output_count)): ?>
                                    <?php echo number_format((float)($key->product->weight/$production_lines->production_output_count), 2); ?>

                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td class="bg-success">

                                <?php if(!empty($key->product->cost_price) && !empty($production_lines->production_output_count)): ?>
                                    <?php
                                        $total_sum +=  (($key->qty * $key->product->cost_price)/$production_lines->production_output_count);
                                    ?>
                                    <?php echo number_format((float)(($key->qty * $key->product->cost_price)/$production_lines->production_output_count), 2); ?>

                                <?php else: ?>
                                    <?php
                                        $total_sum +=  ((($key->qty) * (($key->product_id == -1)?$key->estimated_cost:$key->product->cost_price)) / ($production_lines->production_output_count));
                                    ?>
                                    <?php echo number_format((float)(($key->qty) * (($key->product_id == -1)?$key->estimated_cost:$key->product->cost_price)) / ($production_lines->production_output_count),3); ?>

                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr class="bg-secondary">
                        <td colspan="6" class="text-center">مجموع تكلفة انتاج الوحدة الواحدة</td>
                        <td>
                            <?php
                                echo number_format((float)$total_sum,2);
                            ?>
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </td>
    </tr>
    </tbody>
</table>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/production/production_line/ajax/summery_production_inputs_table.blade.php ENDPATH**/ ?>