<table class="table table-hover table-bordered table-sm">
    <thead>
    <tr>
        <th>التاريخ</th>
        <th>التصنيف</th>
        <th>الوصف</th>
        <th>القيمة</th>

        <th>اضافة بواسطة</th>
        <th></th>
    </tr>
    </thead>
    <tbody>
    <?php if($expenses->isEmpty()): ?>
        <tr>
            <td colspan="7" class="text-center">لا توجد بيانات</td>
        </tr>
    <?php else: ?>
        <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key->expense_date); ?></td>
                <td><?php echo e($key->expenses_category->title ?? ''); ?></td>
                <td><?php echo e($key->description); ?></td>
                <td><?php echo e($key->amount); ?> <?php echo e($key->currency->currency_symbol ?? ''); ?></td>

















                <td><?php echo e($key->user->name); ?></td>
                <td>
                    <button type="button" onclick="edit_expenses(<?php echo e($key); ?>)"
                            class="btn btn-success btn-sm"><span
                            class="fa fa-edit"></span></button>
                    <a onclick="return confirm('هل انت متاكد من حذف البيانات ؟')" href="<?php echo e(route('accounting.expenses.delete',['id'=>$key->id])); ?>" class="btn btn-danger btn-sm"><span
                            class="fa fa-trash"></span></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td colspan="3" class="bg-dark text-center">المجموع</td>
            <td>
                <?php $__currentLoopData = $key->total_sum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($key->total_sum); ?> <?php echo e(\App\Models\Currency::where('id',$key->currency_id)->first()->currency_symbol ?? ''); ?> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/expenses/ajax/expenses_table.blade.php ENDPATH**/ ?>