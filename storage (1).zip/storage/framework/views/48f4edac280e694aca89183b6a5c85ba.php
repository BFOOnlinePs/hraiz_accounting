<table class="table table-bordered table-hover table-sm">
    <thead>
        <tr>
            <th></th>
            <th>الصنف</th>
            <th>الكمية</th>
            <th>السعر</th>
            <th>المخزن</th>
        </tr>
    </thead>
    <tbody>
    <?php if(!$data->isEmpty()): ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><input type="checkbox" name="selected_products[]" value="<?php echo e($key->product->id); ?>"></td>
                <td><?php echo e($key->product->product_name_ar); ?></td>
                <td>
                    <input name="quantities[]" max="<?php echo e($key->quantity); ?>" class="form-control" value="<?php echo e($key->quantity); ?>" type="number">
                </td>
                <td>
                    <input name="rates[]" class="form-control" value="<?php echo e($key->rate); ?>" type="text">
                </td>
                <td>
                    <select class="form-control select2bs4" name="wherehouses[]" id="">
                        <?php $__currentLoopData = $wherehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if($item->id == $key->wherehouse->id): ?> selected <?php endif; ?> value="<?php echo e($item->id); ?>"><?php echo e($item->wherehouse_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <tr>
            <td colspan="1" class="text-center">لا توجد بيانات</td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/returns/ajax/invoice_items.blade.php ENDPATH**/ ?>