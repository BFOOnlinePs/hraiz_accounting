<?php $__env->startSection('title'); ?>
    اوامر الانتاج
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title'); ?>
    اوامر الانتاج
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_link'); ?>
    الرئيسية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title_link'); ?>
    اوامر الانتاج
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('style'); ?>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('admin.messge_alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.messge_alert.fail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('production.production_inputs.settings.update')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="">اسم الاعداد</label>
                                        <input type="text" class="form-control" name="production_name" value="<?php echo e($data->production_name); ?>">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="">القيمة</label>
                                        <input type="text" class="form-control" name="production_value" value="<?php echo e($data->production_value); ?>">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="">ملاحظات</label>
                                        <textarea class="form-control" name="production_description" id="" cols="30" rows="3"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 text-center">
                            <div class="form-group">
                                <label for="">الصورة</label>
                                <br>
                                <img width="120px" src="<?php echo e(asset('storage/production/'.$data->product_image)); ?>" alt="">
                            </div>
                            <input type="file" class="form-control" name="product_image">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success">حفظ التعديلات</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/production/settings/edit.blade.php ENDPATH**/ ?>