<?php $__env->startSection('title'); ?>
    تعديل اوامر الانتاج
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title'); ?>
    تعديل اوامر الانتاج
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_link'); ?>
    خطوط الانتاج الانتاج
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title_link'); ?>
    تعديل اوامر الانتاج
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.messge_alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.messge_alert.fail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <div class="card-body">
            <div id="example1_wrapper" class="dataTables_wrapper dt-bootstrap4">
                <form action="<?php echo e(route('production.production_inputs.update_production_orders')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($data->id); ?>" name="id">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">رقم الموظف</label>
                                <select class="form-control" name="employee_id" id="">
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key->id); ?>"><?php echo e($key->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">حالة الامر</label>
                                <select class="form-control" name="status" id="">
                                    <option <?php if($data->status == 'new'): ?> selected <?php endif; ?> value="new">new</option>
                                    <option <?php if($data->status == 'process'): ?> selected <?php endif; ?> value="process">process</option>
                                    <option <?php if($data->status == 'complete'): ?> selected <?php endif; ?> value="complete">complete</option>
                                </select>
                            </div>
                        </div>






                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">تاريخ التسليم</label>
                                <input type="date" value="<?php echo e($data->submission_date); ?>" name="submission_date" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">ملاحظات</label>
                                <textarea class="form-control" name="note" id="" cols="30" rows="3"><?php echo e($data->note); ?></textarea>
                            </div>
                        </div>
                        <button class="btn btn-success">حفظ التعديلات</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.full.min.js')); ?>"></script>
    <script>
        $(function () {
            $('.select2bs4').select2({
                theme: 'bootstrap4'
            })
        })
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/production/production_line/edit_production_orders.blade.php ENDPATH**/ ?>