<table style="width: 100%" class="table-sm table-bordered table-hover">
    <thead>
        <tr>
            <th></th>
            <th>اسم الصنف</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <input type="hidden" value="<?php echo e($key->unit_id); ?>" id="unit_id_<?php echo e($key->id); ?>">
            <tr>
                <td>
                    <input type="checkbox"
                           onchange="create_product_ajax(this.value)"
                           name="checkbox[]"
                           value="<?php echo e($key->id); ?>">
                </td>
                <td>
                    <?php if(!empty($key->product_photo)): ?>
                    <img style="width: 30px" src="<?php echo e(asset('storage/product/'.$key->product_photo)); ?>" alt="">
                    <?php else: ?>
                    <img style="width: 30px" src="<?php echo e(asset('img/no_img.jpeg')); ?>" alt="">
                    <?php endif; ?>
                    <?php echo e($key->product_name_ar); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($data->links()); ?>

<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/orders/procurement_officer/product/ajax/search_product.blade.php ENDPATH**/ ?>