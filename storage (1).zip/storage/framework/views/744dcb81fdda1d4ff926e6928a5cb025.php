<?php if(\Illuminate\Support\Facades\Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/messge_alert/success.blade.php ENDPATH**/ ?>