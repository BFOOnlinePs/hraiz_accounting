<div class="modal fade" id="create_payment_bond_modal">
    <div class="modal-dialog modal-xl">
        <form action="<?php echo e(route('accounting.bonds.payment_bond.create')); ?>" method="post" id="bonds_create" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="invoice_modal_type" value="invoice">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">اضافة سند قبض</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="">اختر فاتورة</label>
                                <input readonly type="text" class="form-control" name="invoice_id" id="invoice_select">






                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="">الرقم المرجعي</label>
                                <input type="text" name="reference_number" class="form-control" placeholder="الرقم المرجعي">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="">العملة</label>
                                <select class="form-control select2bs4" required name="currency_id" id="">
                                    <option value="">اختر العملة ...</option>
                                    <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key->id); ?>"><?php echo e($key->currency_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="">القيمة</label>
                                <input required id="invoice_amount" type="text" name="amount" class="form-control text-center" style="background-color: palegoldenrod;font-size: 50px;height: 80px !important;vertical-align: middle;padding-top: 25px" pattern="[0-9]+" title="يجب ادخال ارقام فقط" placeholder="قيمة سند القبض">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="">الملاحظات</label>
                                <textarea class="form-control" name="notes" id="" cols="30" rows="3"></textarea>
                            </div>
                        </div>
                        <div class="col-md-1">
                            <div class="custom-control custom-radio">
                                <input class="custom-control-input" type="radio" value="cash" id="cash" name="customRadio" checked="">
                                <label for="cash" class="custom-control-label">كاش</label>
                            </div>
                        </div>
                        <div class="col-md-1">
                            <div class="custom-control custom-radio">
                                <input class="custom-control-input" type="radio" value="check" id="check" name="customRadio">
                                <label for="check" class="custom-control-label">شيك</label>
                            </div>
                        </div>
                    </div>
                    <div class="row" style="display: none" id="check_information">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="checkNumber">رقم الشيك</label>
                                <input name="check_number" type="text" class="form-control" id="checkNumber" placeholder="رقم الشيك" pattern="[0-9]+" title="يرجى إدخال رقم شيك صحيح (الأرقام فقط)">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="">تاريخ الاستحقاق</label>
                                <input name="due_date" id="due_date" type="date" class="form-control" placeholder="تاريخ الاستحقاق">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="">اسم البنك</label>
                                <input name="bank_name" id="bank_name" type="text" class="form-control" placeholder="اسم البنك">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="submit" class="btn btn-dark">اضافة البيانات</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">إغلاق</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/bonds/payment_bond/modals/create_payment_bond_modal.blade.php ENDPATH**/ ?>