    <table class="table table-sm table-bordered table-hover">
        <thead>
        <tr>
            <th>اسم الاعداد</th>
            <th>القيمة</th>
            <th>الصورة</th>
            <th>الملاحظات</th>
            <th>العمليات</th>
        </tr>
        </thead>
        <tbody>
        <?php if(!$data->isEmpty()): ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key->production_name); ?></td>
                    <td><?php echo e($key->production_value); ?></td>
                    <td>
                        <img style="width: 80px" src="<?php echo e(asset('storage/production/'.$key->product_image)); ?>" alt="">
                    </td>
                    <td><?php echo e($key->production_description); ?></td>
                    <td>
                        <a class="btn btn-success btn-sm" href="<?php echo e(route('production.production_inputs.settings.edit',['id'=>$key->id])); ?>"><span class="fa fa-edit"></span></a>
                        <a class="btn btn-danger btn-sm" href="<?php echo e(route('production.production_inputs.settings.delete',['id'=>$key->id])); ?>"><span class="fa fa-trash"></span></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr>
                <td colspan="5" class="text-center">لا توجد بيانات</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
<?php echo e($data->links()); ?>

<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/production/settings/ajax/setting_table.blade.php ENDPATH**/ ?>