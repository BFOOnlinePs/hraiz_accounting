<table class="table table-sm table-hover table-bordered">
    <thead>
    <tr>
        <th>الزبون</th>
        <th>تاريخ الاضافة</th>
        <th>تمت الاضافة بواسطة</th>
        <th>ملاحظات</th>
        <th>العملة</th>
        <th>العمليات</th>
    </tr>
    </thead>
    <tbody>
    <?php if(!$data->isEmpty()): ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key->user->name); ?></td>
                <td><?php echo e($key->insert_at); ?></td>
                <td><?php echo e($key->insert_by_user->name); ?></td>
                <td><?php echo e($key->notes); ?></td>
                <td><?php echo e($key->currency->currency_name); ?></td>
                <td>
                    <a class="btn btn-success btn-sm" href="<?php echo e(route('price_offer_sales.edit',['id'=>$key->id])); ?>"><span class="fa fa-edit"></span></a>
                    <a href="<?php echo e(route('price_offer_sales.price_offer_sales_items.price_offer_sales_items_index',['id'=>$key->id])); ?>" class="btn btn-dark btn-sm"><span class="fa fa-search"></span></a>
                    <a class="btn btn-danger btn-sm" href=""><span class="fa fa-trash"></span></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <tr>
            <td colspan="6" class="text-center">لا توجد بيانات</td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/sales/price_offer_sales/ajax/price_offer_sales_table.blade.php ENDPATH**/ ?>