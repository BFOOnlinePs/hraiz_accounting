<table class="table table-sm table-bordered table-hover">
    <thead>
    <tr>
        <th>الرقم المرجعي</th>
        <th>القيمة</th>
        <th>الملاحظات</th>
        <th>العملة</th>
        <th>نوع الدفعة</th>
        <th>اضيفت بواسطة</th>
        <th>الى العميل</th>
        <th>العمليات</th>
    </tr>
    </thead>
    <tbody>
    <?php if($data->isEmpty()): ?>
        <tr>
            <td colspan="8" class="text-center">لا توجد بيانات</td>
        </tr>
    <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key->reference_number); ?></td>
                <td><?php echo e($key->amount); ?></td>
                <td><?php echo e($key->notes); ?></td>
                <td><?php echo e($key->currency->currency_name); ?></td>
                <td>
                    <?php if($key->payment_type == 'cash'): ?>
                        <small class="badge badge-info">كاش</small>
                    <?php else: ?>
                        <small class="badge badge-warning"><span>شيك </span><span data-toggle="modal" data-target="#update_check_payment_type_modal" onclick="get_check_data(<?php echo e($key); ?>)" class="fa fa-money-check"></span></small>
                    <?php endif; ?>
                </td>
                <td><?php echo e($key->users->name); ?></td>
                <td>
                    <?php echo e($key->client->name ?? ''); ?>







                </td>
                <td>
                    <a href="<?php echo e(route('accounting.sales_invoices.invoice_view',['id'=>$key->invoice_id])); ?>" class="btn btn-sm btn-dark"><span class="fa fa-search"></span></a>
                    <a href="<?php echo e(route('accounting.bonds.performance_bond.edit_performance_bonds',['id'=>$key->id])); ?>" class="btn btn-success btn-sm"><span class="fa fa-edit"></span></a>
                    <a href="" class="btn btn-danger btn-sm"><span class="fa fa-trash"></span></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </tbody>
</table>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/bonds/performance_bond/ajax/performance_bonds_table.blade.php ENDPATH**/ ?>