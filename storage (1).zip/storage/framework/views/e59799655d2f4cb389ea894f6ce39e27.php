<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>اصناف الطلبية</title>
    <style>

        @page {
            background-image: url("<?php echo e(asset('img/background/jelanco-background.jpg')); ?>");
            background-image-resize: 6;
            margin-top: 220px;
            margin-bottom: 50px;
            footer: page-footer;
        }

        @page :first {
            background-image: url("<?php echo e(asset('img/background/jelanco-background.jpg')); ?>");
            background-image-resize: 6;
            margin-bottom: 50px;
            margin-top: 220px;
        }

        /*.title {*/
        /*    padding-top: 220px;*/
        /*}*/

        table, td, th {
            border: 1px solid black;
        }

        .table {
            border-collapse: collapse;
            width: 100%;
            text-align: center;
        }

        th {
            height: 70%;
        }
    </style>

</head>
<body>
<h4 class="title" style="text-align: right"><?php echo e(\Carbon\Carbon::now()->toDateString()); ?></h4>
<h3>To: <?php echo e($company->name); ?></h3>
<h2 style="text-align: center;font-weight: bold"><u>NEW ORDER - <?php echo e($order->reference_number); ?></u></h2>
<p>Dear , <?php echo e($company->contact_person); ?></p>
<p>Please prepare the below mentioned order:</p>













<table class="table" cellpadding="10">
    <tr>
        <th></th>
        
        <th>product name</th>
        <th>qty</th>
        <th>unit</th>
        <th style="width: 80px">price</th>
    </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php if(!empty($key['product']->product_photo)): ?>
                    <img style="width: 80px;height: 80px" src="<?php echo e(asset('storage/product/'.$key['product']->product_photo)); ?>" width="100px" alt="">
                <?php else: ?>
                    <img style="width: 80px;height: 80px" src="<?php echo e(asset('img/no_img.jpeg')); ?>" width="100px" alt="">
                <?php endif; ?>
            </td>
            
            <td align="left" style="padding: 0px 20px 0px 20px;text-align: center">
                <span style="font-weight: bold">
                                    <?php echo e($key['product']->product_name_en); ?>

                </span>
                
                
                
                
            </td>
            <td><?php echo e($key->qty); ?></td>
            <td><?php echo e($key['unit']->unit_name_en); ?></td>
            <td></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<htmlpagefooter name="page-footer">
    <hr>
    <div style="display: block;text-align:center">Page {PAGENO} of {nbpg}</div>
</htmlpagefooter>

</body>
</html>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/orders/procurement_officer/pdf/product_supplier.blade.php ENDPATH**/ ?>