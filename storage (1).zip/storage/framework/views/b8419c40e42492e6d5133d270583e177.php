<table class="table table-sm table-bordered table-hover">
    <thead>
    <tr>
        <th>المنتج المجمع</th>
        <th>العمليات</th>
    </tr>
    </thead>
    <tbody>
    <?php if($data->isEmpty()): ?>
        <tr>
            <td colspan="5" class="text-center">لا توجد بيانات</td>
        </tr>
    <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($key->product->product_name_ar); ?>

                </td>
                <td>
                    <a href="<?php echo e(route('product.edit_assembled_product',['id'=>$key->id])); ?>" class="btn btn-success btn-sm"><span class="fa fa-edit"></span></a>
                    <button onclick="delete_assembled_product_ajax(<?php echo e($key->id); ?>)" class="btn btn-danger btn-sm"><span class="fa fa-trash"></span></button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </tbody>
</table>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/product/ajax/list_assembled_product.blade.php ENDPATH**/ ?>