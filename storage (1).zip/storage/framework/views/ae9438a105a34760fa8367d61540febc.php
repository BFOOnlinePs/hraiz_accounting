<table class="table table-bordered table-hover table-sm">
    <thead>
        <tr>
            <th>الرقم المرجعي</th>
            <th>العميل</th>
            <th>تاريخ الفاتورة</th>
            <th>تاريخ الاستحقاق</th>
            <th>الحالة</th>
            <th>نوع الفاتورة</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
    <?php if($data->isEmpty()): ?>
        <tr>
            <td colspan="5" class="text-center">لا توجد نتائج للبحث</td>
        </tr>
    <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key->invoice_reference_number); ?></td>
                <td><?php echo e($key->client->name); ?></td>
                <td><?php echo e($key->bill_date); ?></td>
                <td><?php echo e($key->due_date); ?></td>
                <td>
                    <?php if($key->status == 'stage'): ?>
                        <small class="badge badge-success">مرحل</small>
                    <?php else: ?>
                        <small class="badge badge-warning">غير مرحل</small>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($key->invoice_type == 'sales'): ?>
                        مبيعات
                    <?php elseif($key->invoice_type == 'purchases'): ?>
                        مشتريات
                    <?php endif; ?>
                </td>
                <td>
                    <a target="_blank" href="<?php if($key->invoice_type == 'sales'): ?> <?php echo e(route('accounting.sales_invoices.invoice_view',['id'=>$key->id])); ?> <?php else: ?> <?php echo e(route('accounting.purchase_invoices.invoice_view',['id'=>$key->id])); ?> <?php endif; ?>" class="btn btn-dark btn-sm"><span class="fa fa-eye"></span></a>
                    <button onclick="select_get_invoice_number_from_select_invoice(<?php echo e($key->id); ?>)" class="btn btn-sm btn-success"><span class="fa fa-check"></span></button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </tbody>
</table>
<div id="pagination">

</div>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/bonds/payment_bond/ajax/list_invoice_clients.blade.php ENDPATH**/ ?>