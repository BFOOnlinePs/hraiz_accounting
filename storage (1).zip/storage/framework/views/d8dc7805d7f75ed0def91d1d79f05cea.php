<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
        befoundonline.ps
    </div>
    <!-- Default to the left -->

</footer>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/layouts/footer.blade.php ENDPATH**/ ?>