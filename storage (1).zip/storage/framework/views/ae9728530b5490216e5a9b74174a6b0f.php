<table class="table table-sm table-hover table-bordered">
    <thead>
    <tr>
        <th>الرقم المرجعي للفاتورة</th>
        <th>نوع المردود</th>
        <th>ملاحظات</th>
        <th></th>
    </tr>
    </thead>
    <tbody>
        <?php if($data->isEmpty()): ?>
            <tr>
                <td colspan="4" class="text-center">لا توجد بيانات</td>
            </tr>
        <?php else: ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key->invoice->invoice_reference_number ?? 'من غير فاتورة'); ?></td>
                    <td>
                        <?php if($key->returns_type == 'sales'): ?>
                            مبيعات
                        <?php else: ?>
                            مشتريات
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($key->notes); ?></td>
                    <td>
                        <a href="<?php echo e(route('accounting.returns.returns_details',['id'=>$key->id])); ?>" class="btn btn-dark btn-sm"><span class="fa fa-search"></span></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
</table>
<?php echo e($data->links()); ?>

<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/returns/ajax/returns_table.blade.php ENDPATH**/ ?>