
<div class="col-sm-12">
    <div style="width: 100%" class="justify-content-center">
        <?php echo e($data->links()); ?>

    </div>
    <div class="table-responsive">
        <table id="example1" class="table  table-bordered table-hover dataTable dtr-inline"
               aria-describedby="example1_info">
            <thead>
            <tr>
                
                <th style="width: 10px">#</th>
                <th style="width: 170px">الرقم المرجعي للطلبية</th>
                <th style="min-width: 200px">الترسية</th>
                <th style="width: 180px">متابعة بواسطة</th>
                <th style="width: 150px">تاريخ الطلبية</th>
                <th style="width: 200px">حالة الطلبية</th>
                <th style="width: 100px">العمليات</th>
            </tr>
            </thead>
            <tbody>
            <?php if($data->isEmpty()): ?>
                <tr>
                    <td colspan="7" class="text-center"><h3 class="p-5">لا توجد نتائج</h3></td>
                </tr>
            <?php else: ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="">
                        
                        
                        <td><?php echo e(($data ->currentpage()-1) * $data ->perpage() + $loop->index + 1); ?></td>
                        <td><?php echo e($key->reference_number); ?>

                            <?php if(in_array(['3','9'],json_decode(auth()->user()->user_role))): ?>
                                <span onclick="getReferenceNumber(<?php echo e($key->id); ?>)" class="fa fa-edit text-success"
                                      style="float: left" data-toggle="modal"
                                      data-target="#modal-reference_number"></span></td>
                            <?php endif; ?>
                        <td>
                            <?php $__currentLoopData = $key->supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($child['name']->name); ?>,
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <?php if($view == 'officer_view' || in_array(['9'],json_decode(auth()->user()->user_role))): ?>
                                <select disabled onchange="updateToUser(<?php echo e($key->id); ?> , this.value)" class="" name="" id="">
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($user->id == ($key['to_user']->id ?? 1)): ?> selected <?php endif; ?> value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            <?php else: ?>
                                <select onchange="updateToUser(<?php echo e($key->id); ?> , this.value)" class="" name="" id="">
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($user->id == ($key['to_user']->id ?? 1)): ?> selected <?php endif; ?> value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo e($key->inserted_at); ?>

                            <?php if(!in_array(['9'],json_decode(auth()->user()->user_role))): ?>
                            <span onclick="showDueDate(<?php echo e($key->id); ?>)" class="fa fa-edit text-success"
                                  style="float: left" data-toggle="modal" data-target="#modal-show_due_date"></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(!in_array(['9'],json_decode(auth()->user()->user_role))): ?>
                            <select

                            style="background-color: <?php echo e($key['order_status_color']->status_color ?? 'white'); ?>;color: <?php echo e($key['order_status_color']->status_text_color ?? 'black'); ?>;"
                            onchange="updateOrderStatus(<?php echo e($key->id); ?> , this.value)" class="" name=""
                            id="order_status_<?php echo e($key->id); ?>">
                            <?php $__currentLoopData = $order_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php if($status->id == $key->order_status): ?> selected
                                        <?php endif; ?> value="<?php echo e($status->id); ?>"><?php echo e($status->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php else: ?>
                        <select
                        disabled
                                style="background-color: <?php echo e($key['order_status_color']->status_color ?? 'white'); ?>;color: <?php echo e($key['order_status_color']->status_text_color ?? 'black'); ?>;"
                                 class="" name=""
                                id="order_status_<?php echo e($key->id); ?>">
                                <?php $__currentLoopData = $order_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($status->id == $key->order_status): ?> selected
                                            <?php endif; ?> value="<?php echo e($status->id); ?>"><?php echo e($status->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a target="_blank" data-toggle="tooltip" data-placement="top" title="التفاصيل"
                               <?php if(in_array(['9'],json_decode(auth()->user()->user_role))): ?> href="<?php echo e(route('orders.order_items.index',['order_id'=>$key->id])); ?>"  <?php else: ?> href="<?php echo e(route('procurement_officer.orders.product.index',['order_id'=>$key->id])); ?>" <?php endif; ?>
                               class="btn btn-dark btn-sm"><span class="fa fa-search"></span></a>
                            
                            
                            
                            <?php if(!in_array(['3','9'],json_decode(auth()->user()->user_role))): ?>

                                <a data-toggle="tooltip" data-placement="top" title="حذف"
                                   href="<?php echo e(route('orders.procurement_officer.delete_order',['id'=>$key->id])); ?>"
                                   onclick="return confirm('هل انت متاكد من عملية الحذف علما انه بعد الحذف سوف يتم نقله لسلة المحذوفات')"
                                   class="btn btn-danger btn-sm"><span class="fa fa-trash"></span></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php echo e($data->links()); ?>

</div>

<script>
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })
</script>


<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/orders/procurement_officer/ajax/order_table.blade.php ENDPATH**/ ?>