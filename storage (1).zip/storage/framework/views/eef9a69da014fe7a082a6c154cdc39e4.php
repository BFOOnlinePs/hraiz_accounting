<div class="form-group">
    <a href="<?php echo e(route('users.procurement_officer.index')); ?>" class="btn btn-sm btn-warning form-control">موظف المشتريات</a>
</div>
<div class="form-group">
    <a href="<?php echo e(route('users.storekeeper.index')); ?>" class="btn btn-sm btn-warning form-control">أمين المستودع</a>
</div>
<div class="form-group">
    <a href="<?php echo e(route('users.secretarial.index')); ?>" class="btn btn-sm btn-warning form-control">سكرتيريا</a>
</div>
<div class="form-group">
    <a href="<?php echo e(route('users.supplier.index')); ?>" class="btn btn-sm btn-warning form-control">الموردين</a>
</div>
<div class="form-group">
    <a href="<?php echo e(route('users.delivery_company.index')); ?>" class="btn btn-sm btn-warning form-control">شركات الشحن</a>
</div>
<div class="form-group">
    <a href="<?php echo e(route('users.clearance_companies.index')); ?>" class="btn btn-sm btn-warning form-control">شركات التخليص</a>
</div>
<div class="form-group">
    <a href="<?php echo e(route('users.local_carriers.index')); ?>" class="btn btn-sm btn-warning form-control">شركات النقل المحلي</a>
</div>
<div class="form-group">
    <a href="<?php echo e(route('users.insurance_companies.index')); ?>" class="btn btn-sm btn-warning form-control">شركات التأمين</a>
</div>
<div class="form-group">
    <a href="<?php echo e(route('users.clients.index')); ?>" class="btn btn-sm btn-warning form-control">زبائن</a>
</div>
<div class="form-group">
    <a href="<?php echo e(route('users.employees.index')); ?>" class="btn btn-sm btn-warning form-control">موظفين</a>
</div>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/users/includes/users_sidebar.blade.php ENDPATH**/ ?>