<table class="table table-sm table-hover table-bordered">
    <thead>
        <tr>
            <th>اسم المدخل</th>
            <th>التكلفة</th>
            <th>تكلفة الوحدة الواحدة</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($key->production_input_name); ?></td>
            <td>
                <input id="estimated_cost_worker_<?php echo e($key->id); ?>" <?php if(!$key->production_input_name == 'عامل'): ?> readonly <?php endif; ?> onchange="update_estimated_cost_ajax(<?php echo e($key->id); ?>,this.value,'estimated_cost')" type="text" value="<?php echo e($key->estimated_cost); ?>">
                <div id="estimated_cost_worker_loader_<?php echo e($key->id); ?>" style="display: none;font-size: 7px" class="col text-center p-5"><i class="fas fa-3x fa-sync-alt fa-spin"></i></div>
            </td>
            <td>
                <input id="cost_per_unit_worker_<?php echo e($key->id); ?>"
                       <?php if(!$key->production_input_name == 'عامل'): ?> readonly <?php endif; ?>
                       type="text"
                       onchange="update_estimated_cost_ajax(<?php echo e($key->id); ?>, this.value, 'product')"
                       value="<?php echo e(($key->production_lines->production_output_count != 0) ? number_format((float)($key->estimated_cost) / ($key->production_lines->production_output_count),2) : ''); ?>">
                <div id="cost_per_unit_worker_loader_<?php echo e($key->id); ?>" style="display: none;font-size: 7px" class="col text-center p-5"><i class="fas fa-3x fa-sync-alt fa-spin"></i></div>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/production/production_line/ajax/cost_of_production_output_table.blade.php ENDPATH**/ ?>