<table class="table table-hover table-bordered table-sm">
    <thead>
    <tr>
        <th>اسم الزبون</th>
        <th></th>
    </tr>
    </thead>
    <tbody>
    <?php if($data->isEmpty()): ?>
        <tr>
            <td colspan="2" class="text-center">لا توجد نتائج</td>
        </tr>
    <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key->name); ?></td>
                <td>
                    <a href="<?php echo e(route('accounting.account-statement.account_statement_details',['id'=>$key->id,'user_type'=>'customer'])); ?>" class="btn btn-dark btn-sm"><span class="fa fa-search"></span></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </tbody>
</table>
<?php echo e($data->links()); ?>

<script>
    
    
    

    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
</script>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/account_statement/ajax/list_customers_table.blade.php ENDPATH**/ ?>