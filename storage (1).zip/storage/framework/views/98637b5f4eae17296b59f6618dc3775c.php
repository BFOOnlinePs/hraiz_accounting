<?php $__env->startSection('title'); ?>
    تعديل زبون
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title'); ?>
    تعديل زبون
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_link'); ?>
    الزبائن
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title_link'); ?>
    تعديل زبون
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.messge_alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.messge_alert.fail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-header text-center">
            <h5 class="text-bold">تعديل زبون ( <?php echo e($data->name); ?> )</h5>
        </div>
        <div class="card-body">

            <form action="<?php echo e(route('users.update',['id'=>$data->id])); ?>" method="post"
                  enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div>
                            <div class="card card-warning">
                                <div class="card-header text-center">
                                    <span>المعلومات العامة</span>
                                </div>
                                <div class="card-body p-4">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <label for="">الاسم الكامل</label>
                                                <input value="<?php echo e(old('name',$data->name)); ?>" placeholder="الاسم الكامل"
                                                       name="name" class="form-control"
                                                       type="text">
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="">الايميل</label>
                                                <input value="<?php echo e(old('email',$data->email)); ?>" name="email"
                                                       placeholder="الايميل" class="form-control"
                                                       type="text">
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="">كلمة المرور</label>
                                                <input <?php echo e(old('password')); ?> placeholder="كلمة المرور" name="password"
                                                       class="form-control"
                                                       type="text">
                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col">
                                                    <label>رقم الهاتف الاول</label>
                                                    <input value="<?php echo e(old('user_phone1',$data->user_phone1)); ?>"
                                                           placeholder="رقم الهاتف الاول" class="form-control"
                                                           name="user_phone1" type="text">
                                                    <?php $__errorArgs = ['user_phone1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col">
                                                    <label for="">رقم الهاتف الثاني</label>
                                                    <input value="<?php echo e(old('user_phone2',$data->user_phone2)); ?>"
                                                           placeholder="رقم الهاتف الثاني" class="form-control"
                                                           name="user_phone2" type="text">
                                                    <?php $__errorArgs = ['user_phone2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="">الموقع الالكتروني</label>
                                                <input value="<?php echo e(old('user_website',$data->user_website)); ?>"
                                                       placeholder="الموقع الالكتروني" name="user_website"
                                                       class="form-control" type="text">
                                            </div>
                                            <div class="form-group">
                                                <label for="">العنوان الكامل</label>
                                                <textarea class="form-control" placeholder="العنوان الكامل"
                                                          name="user_address" id="" cols="30"
                                                          rows="3"><?php echo e(old('user_address',$data->user_address)); ?></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label for="">تصنيف المستخدم</label>
                                                <input class="form-control" type="text" name="user_category"
                                                       placeholder="تنصيف المستخدم">
                                            </div>
                                            <div class="form-group">


                                                <div class="row">
                                                    <div class="col-md-5 text-center">

                                                        <img width="150"
                                                             src="<?php echo e(asset('storage/user_photo/'. $data->user_photo)); ?>"
                                                             alt="">
                                                        <br>
                                                        <label for="exampleInputFile">الصورة الشخصية</label>

                                                    </div>
                                                    <div class="col-md-7 pt-5">
                                                        <div class="input-group">
                                                            <div class="custom-file">
                                                                <input type="file" class="custom-file-input" id="exampleInputFile">
                                                                <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                                            </div>
                                                            <div class="input-group-append">
                                                                <span class="input-group-text">رفع</span>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>










                                                <?php $__errorArgs = ['user_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <h5 class="alert alert-warning">الصلاحيات</h5>
                                                <br>
                                                <?php
                                                    $user_role_array = json_decode($data->user_role??'[]');
                                                ?>
                                                <div class="row">
                                                  <?php $__currentLoopData = $user_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <div class="col-md-3">
                                                    <input <?php if(in_array($key->id,$user_role_array)): ?> checked <?php endif; ?> name="role_level[]" value="<?php echo e($key->id); ?>" id="user_role_<?php echo e($loop->index); ?>" type="checkbox">
                                                    <label for="user_role_<?php echo e($loop->index); ?>"><?php echo e($key->name); ?></label>
                                                  </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>

                                            </div>
                                            <div class="form-group">
                                                <label for="">ملاحظات</label>
                                                <textarea placeholder="الملاحظات" class="form-control" name="user_notes"
                                                          id="" cols="30"
                                                          rows="5"><?php echo e(old('user_notes',$data->user_notes)); ?></textarea>
                                                <?php $__errorArgs = ['user_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>




























































                </div>
                <button class="btn btn-primary" style="width: 300px">تعديل</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/users/clients/edit.blade.php ENDPATH**/ ?>