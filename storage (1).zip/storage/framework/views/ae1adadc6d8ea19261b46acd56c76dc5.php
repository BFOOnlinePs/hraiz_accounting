<table class="table table-sm table-bordered table-hover">
    <thead>
    <tr>
        <th>الرقم المرجعي</th>
        <th>القيمة</th>
        <th>الملاحظات</th>
        <th>العملة</th>
        <th>نوع الدفعة</th>
        <th>اضيفت بواسطة</th>
        <th>الى العميل</th>
        <th>العمليات</th>
    </tr>
    </thead>
    <tbody>
    <?php if($data->isEmpty()): ?>
        <tr>
            <td colspan="8" class="text-center">لا توجد بيانات</td>
        </tr>
    <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key->reference_number); ?></td>
                <td><?php echo e($key->amount); ?></td>
                <td><?php echo e($key->notes); ?></td>
                <td><?php echo e($key->currency->currency_name); ?></td>
                <td>
                    <?php if($key->payment_type == 'cash'): ?>
                        <small class="badge badge-info">كاش</small>
                    <?php else: ?>
                        شيك
                    <?php endif; ?>
                </td>
                <td><?php echo e($key->users->name); ?></td>
                <td><?php echo e(\App\Models\User::where('id',$key->invoice->client_id)->first()->name); ?></td>
                <td>
                    <a href="<?php echo e(route('accounting.sales_invoices.invoice_view',['id'=>$key->invoice_id])); ?>" class="btn btn-sm btn-dark"><span class="fa fa-search"></span></a>
                    <a href="<?php echo e(route('accounting.bonds.payment_bond.edit_payment_bonds',['id'=>$key->id])); ?>" class="btn btn-success btn-sm"><span class="fa fa-edit"></span></a>
                    <a href="" class="btn btn-danger btn-sm"><span class="fa fa-trash"></span></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </tbody>
</table>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/bonds/payment_bond/ajax/bonds_table.blade.php ENDPATH**/ ?>