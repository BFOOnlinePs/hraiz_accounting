<table class="table table-bordered">
    <thead>
    <tr>
        <td>#</td>
        <td>الرقم المرجعي</td>
        <th>تاريخ الفاتورة</th>
        <th>تاريخ التسليم</th>
        <th>العميل</th>
        <th>الضريبة الاولى</th>
        <th>الضريبة الثانية</th>
        <th>الملاحظات</th>
        <th>العمليات</th>
    </tr>
    </thead>
    <tbody>
    <?php if($data->isEmpty()): ?>
        <tr>
            <td colspan="8" class="text-center">لا توجد بيانات</td>
        </tr>
    <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(($data ->currentpage()-1) * $data ->perpage() + $loop->index + 1); ?></td>
                <td><?php echo e($key->invoice_reference_number); ?></td>
                <td><?php echo e($key->bill_date); ?></td>
                <td><?php echo e($key->due_date); ?></td>
                <td><?php echo e(App\Models\User::where('id',$key->client_id)->value('name')); ?></td>
                <td><?php echo e($key->tax_id); ?></td>
                <td><?php echo e($key->tax_id2); ?></td>
                <td><?php echo e($key->note); ?></td>
                <td>
                    <a href="<?php echo e(route('accounting.purchase_invoices.invoice_view',['id'=>$key->id])); ?>" class="btn btn-dark btn-sm"><span class="fa fa-search"></span></a>
                    <a href="<?php echo e(route('accounting.purchase_invoices.edit_invoices',['id'=>$key->id])); ?>" class="btn btn-success btn-sm"><span class="fa fa-edit"></span></a>
                    <a href="<?php echo e(route('accounting.purchase_invoices.delete_invoices',['id'=>$key->id])); ?>" onclick="return confirm('هل تريد حذف البيانات ؟')" class="btn btn-danger btn-sm"><span class="fa fa-trash"></span></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </tbody>
</table>
<?php echo e($data->links()); ?>

<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/purchase_invoices/ajax/invoice_table.blade.php ENDPATH**/ ?>