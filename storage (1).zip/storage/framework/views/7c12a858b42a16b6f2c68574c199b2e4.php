<?php $__env->startSection('title'); ?>
    اوامر الانتاج
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title'); ?>
    اوامر الانتاج
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_link'); ?>
    الرئيسية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title_link'); ?>
    اوامر الانتاج
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.messge_alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.messge_alert.fail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </button>
    <button class="btn btn-dark" data-toggle="modal" data-target="#create_production_order_modal">اضافة امر انتاج</button>
    <div class="card mt-2">
        <div class="card-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered ">
                            <thead>
                                <tr>
                                    <th>خط الانتاج</th>
                                    <th>الموظف</th>
                                    <th>الحالة</th>
                                    <th>تاريخ الانشاء</th>
                                    <th>تاريخ التسليم</th>
                                    <th>الكمية</th>
                                    <th>الملاحظات</th>
                                    <th>العمليات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key->production_lines->production_name); ?></td>
                                        <td><?php echo e($key->user->name); ?></td>
                                        <td>
                                            <?php if($key->status == 'process'): ?>
                                                <small class="badge badge-warning">قيد المعالجة</small>
                                            <?php elseif($key->status == 'new'): ?>
                                                <small class="badge badge-info">جديد</small>
                                            <?php elseif($key->status == 'complete'): ?>
                                                <small class="badge badge-success">مكتمل</small>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($key->insert_at); ?></td>
                                        <td><?php echo e($key->submission_date); ?></td>
                                        <td><?php echo e($key->qty); ?></td>
                                        <td><?php echo e($key->notes); ?></td>
                                        <td>
                                            <a class="btn btn-dark btn-sm" href="<?php echo e(route('production.production_inputs.index',['id'=>$key->production_lines->id])); ?>"><span class="fa fa-search"></span></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.production.production_orders.modals.create_production_order_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/production/production_orders/index.blade.php ENDPATH**/ ?>