<?php $__env->startSection('title'); ?>
    فواتير المبيعات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title'); ?>
    فواتير المبيعات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_link'); ?>
    الرئيسية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title_link'); ?>
    فواتير المبيعات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.messge_alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.messge_alert.fail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <a href="<?php echo e(route('accounting.sales_invoices.new_invoices_index')); ?>" class="btn btn-dark text-white mb-2">
        فاتورة جديدة
    </a>
    <button type="button" class="btn btn-dark mb-2" data-toggle="modal" data-target="#modal-lg">
        فاتورة من عرض سعر
    </button>
    <div class="card p-3">
        <div class="row">
            <div class="col">
                <div class="form-group">
                    <label for="">رقم المرجع</label>
                    <input onkeyup="invoice_table_index_ajax()" placeholder="رقم المرجع" id="invoice_reference_number"
                           class="form-control" type="text">
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label for="">المورد</label>
                    <select onchange="invoice_table_index_ajax()" class="select2bs4 form-control supplier_select2" name="supplier_id" id="supplier_user_id">
                        <option value="">جميع الموردين</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->id); ?>"><?php echo e($key->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>











            <div class="col">
                <div class="form-group">
                    <label for="">حالة الطلبية</label>
                    <select onchange="getOrderTable()" class="form-control" name="order_status" id="order_status">
                        <option value="">جميع الحالات</option>
                        
                        
                        
                        
                        
                    </select>
                </div>
            </div>












        </div>
    </div>

    <div class="card">

        

        <div class="card-body">
            <div id="invoice_table">

            </div>






































        </div>

    </div>
    <div class="modal fade" id="modal-lg">
        <div class="modal-dialog modal-xl">
            <form action="<?php echo e(route('accounting.purchase_invoices.create_purchase_invoices_from_order')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="order_id" id="order_input">
                <input type="hidden" name="supplier_user_id" id="supplier_input">
                <input type="hidden" name="invoice_type" value="sales">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">فاتورة من عرض سعر</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="">بحث عن عرض سعر</label>
                                    <input onkeyup="search_order_ajax()" id="input_search" type="text" class="form-control" placeholder="ابحث عن طلبية">
                                    
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="">المورد</label>
                                    <select class="form-control select2bs4" name="supplier_id" onchange="search_order_ajax()" id="supplier_id">
                                        <option value="">اختر المورد</option>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key->id); ?>"><?php echo e($key->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12" id="search_order">

                            </div>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">اغلاق</button>
                        
                    </div>

                </div>
            </form>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/plugins/select2/js/select2.full.min.js')); ?>"></script>

<script>
    function search_order_ajax(page) {
            var csrfToken = $('meta[name="csrf-token"]').attr('content');
            var headers = {
                "X-CSRF-Token": csrfToken
            };
            $.ajax({
                url: '<?php echo e(route('accounting.sales_invoices.search_order_ajax')); ?>',
                method: 'post',
                headers: headers,
                data: {
                    'input_search': document.getElementById('input_search').value,
                    'supplier_id': document.getElementById('supplier_id').value,
                    'page': page
                },
                success: function (data) {
                    console.log(data);
                    $('#search_order').html(data.view);
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert('error');
                }
            });
        }
    function invoice_table_index_ajax(page) {
            var csrfToken = $('meta[name="csrf-token"]').attr('content');
            var headers = {
                "X-CSRF-Token": csrfToken
            };
            $.ajax({
                url: '<?php echo e(route('accounting.sales_invoices.invoice_table_index_ajax')); ?>',
                method: 'post',
                headers: headers,
                data: {
                    'supplier_user_id': document.getElementById('supplier_user_id').value,
                    'invoice_reference_number': document.getElementById('invoice_reference_number').value,
                    'page': page
                },
                success: function (data) {
                    $('#invoice_table').html(data.view);
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert('error');
                }
            });
        }


        window.onload = (event) => {
            search_order_ajax(page);
            invoice_table_index_ajax(page);
        };

        var page = 1;
        $(document).on('click', '.pagination a', function(event){
            event.preventDefault();
            page = $(this).attr('href').split('page=')[1];
            search_order_ajax(page)
            invoice_table_index_ajax(page);
            });
</script>

<script>
    $(function(){
        $('.select2bs4').select2({
            theme: 'bootstrap4'
        })
    })
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/sales_invoices/index.blade.php ENDPATH**/ ?>