



















































































































<table class="table table-bordered table-hover table-sm">
    <thead>
        <tr>
            <th>المستند</th>
            <th>التاريخ</th>
            <th>دائن</th>
            <th>مدين</th>
            <th>الرصيد</th>
            <th>البيان</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
    <?php
        $sumCreditor = 0;
        $sumDebtor = 0;
        $amount = 0;
    ?>
    <?php if($data->isEmpty()): ?>
        <tr>
            <td colspan="6" class="text-center">لا توجد بيانات</td>
        </tr>
    <?php else: ?>
        <tr>
            <td></td>
            <td></td>
            <td>0</td>
            <td>0</td>
            <td>0</td>
            <td>رصيد اول المدة</td>
            <td></td>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key->reference_number); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($key->created_at)->format('Y-m-d')); ?></td>
                <td>
                    <?php if($key->type == 'purchase' || $key->type == 'payment_bond' || $key->type == 'return_sales'): ?>
                        <?php echo e($key->amount); ?>

                        <?php
                            $sumCreditor += $key->amount;
                            $amount -= $key->amount;
                        ?>
                    <?php else: ?>
                        0
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($key->type == 'sales' || $key->type == 'performance_bond' || $key->type == 'return_purchase'): ?>
                        <?php echo e($key->amount); ?>

                        <?php
                            $sumDebtor += $key->amount;
                            $amount += $key->amount;
                        ?>
                    <?php else: ?>
                        0
                    <?php endif; ?>
                </td>
                <td><?php echo e($amount); ?></td>
                <td>
                    <?php if($key->type == 'sales'): ?>
                        فاتورة مبيعات
                    <?php elseif($key->type == 'payment_bond'): ?>
                        سند قبض
                    <?php elseif($key->type == 'return_sales'): ?>
                        مردود مبيعات
                    <?php elseif($key->type == 'purchase'): ?>
                        فاتورة مشتريات
                    <?php elseif($key->type == 'performance_bond'): ?>
                        سند صرف
                    <?php elseif($key->type == 'return_purchase'): ?>
                        مردود مشتريات
                    <?php endif; ?>
                </td>
                <td><a href="<?php echo e(route('accounting.purchase_invoices.invoice_view',['id'=>$key->invoice_id])); ?>" class="btn btn-warning btn-sm"><span class="fa fa-search"></span></a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr class="bg-dark">
            <td></td>
            <td colspan="" class="text-center">المجموع</td>
            <td><?php echo e($sumCreditor); ?></td>
            <td><?php echo e($sumDebtor); ?></td>
            <td><?php echo e($sumDebtor - $sumCreditor); ?></td>
            <td></td>
            <td></td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>

<div >
    <?php $__currentLoopData = $sumQuery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span class="text-center" style="font-size: 12px">

        <?php if($key->type == 'sales'): ?>

                عدد فواتير المبيعات
                <?php echo e($key->type_count); ?>

            <?php endif; ?>
            <?php if($key->type == 'purchases'): ?>
                عدد فواتير المشتريات
                <?php echo e($key->type_count); ?>

            <?php endif; ?>
            <?php if($key->type == 'payment_bond'): ?>
                عدد سندات القبض
                <?php echo e($key->type_count); ?>

            <?php endif; ?>
            <?php if($key->type == 'performance_bond'): ?>
                عدد سندات الصرف
                <?php echo e($key->type_count); ?>

            <?php endif; ?>
            <?php if($key->type == 'return_sales'): ?>
                عدد مردودات المبيعات
                <?php echo e($key->type_count); ?>

            <?php endif; ?>
            <?php if($key->type == 'return_purchase'): ?>
                عدد مردودات المشتريات
                <?php echo e($key->type_count); ?>

            <?php endif; ?>
            &nbsp;

        </span>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>


<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/account_statement/ajax/account_statement_details_table.blade.php ENDPATH**/ ?>