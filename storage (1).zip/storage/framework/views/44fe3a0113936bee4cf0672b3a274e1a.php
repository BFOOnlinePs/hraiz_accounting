<table class="table table-bordered">
    <thead>
        <tr>
            <th class="sorting sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-sort="ascending">#
            </th>
            <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1">القيمة</th>
            <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1">العملة</th>
            <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1">تمت عملية الإضافة بواسطة</th>
            <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1">تاريخ الاضافة</th>
            <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1">الملاحظات</th>
            <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1">الملف المرفق</th>
            <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1">العمليات</th>
        </tr>
    </thead>
    <tbody>
        <?php if($rewards->isEmpty()): ?>
            <tr>
                <td colspan="7" class="text-center">لا توجد نتائج</td>
            </tr>
        <?php endif; ?>
        <?php $__currentLoopData = $rewards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->index + 1); ?></td>
                <td><?php echo e($key->value); ?></td>
                <td><?php echo e($key->currency->currency_name); ?></td>
                <td><?php echo e($key->user->name); ?></td>
                <td><?php echo e($key->notes); ?></td>
                <td>
                <a target="_blank" href="<?php echo e(asset('storage/discounts_rewards_attachment/'.$key->attached_file)); ?>" download="attachment">تحميل الملف</a>
                </td>
                <td>
                    <button class="btn btn-success btn-sm" onclick="edit_reward(<?php echo e($key->id); ?> , '<?php echo e($key->value); ?>' , <?php echo e($key->currency_id); ?> , '<?php echo e($key->currency->currency_name); ?>' , '<?php echo e($key->notes); ?>' , '<?php echo e($key->attached_file); ?>')"><span class="fa fa-edit pt-1"></span></button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($rewards->links()); ?>

<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/hr/employees/ajax/reward_table.blade.php ENDPATH**/ ?>