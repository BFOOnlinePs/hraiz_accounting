<?php $__env->startSection('title'); ?>
    تعديل عرض سعر بيع
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title'); ?>
    تعديل عرض سعر بيع
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_link'); ?>
    عروض اسعار البيع
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title_link'); ?>
    تعديل عرض سعر بيع
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.messge_alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.messge_alert.fail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('price_offer_sales.update')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="">اسم الزبون</label>
                            <select class="form-control select2bs4" name="customer_id" id="">
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($key->id == $data->customer_id): ?> selected <?php endif; ?> value="<?php echo e($key->id); ?>"><?php echo e($key->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="">العملة</label>
                            <select class="form-control select2bs4" name="currency_id" id="">
                                <?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($key->currency_id == $data->currency_id): ?> selected <?php endif; ?> value="<?php echo e($key->id); ?>"><?php echo e($key->currency_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="">الملاحظات</label>
                            <textarea class="form-control" name="notes" id="" cols="30" rows="3"><?php echo e($data->notes); ?></textarea>
                        </div>
                    </div>
                </div>
                <button class="btn btn-success">حفظ التعديلات</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.full.min.js')); ?>"></script>
    <script>
        $(function () {
            $('.select2bs4').select2({
                theme: 'bootstrap4'
            })
        })
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/sales/price_offer_sales/edit.blade.php ENDPATH**/ ?>