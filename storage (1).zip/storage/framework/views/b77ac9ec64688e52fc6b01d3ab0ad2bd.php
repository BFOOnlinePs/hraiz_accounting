<?php $__env->startSection('title'); ?>
    توصيل دولي (شحن)
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title'); ?>
    <span>توصيل دولي ( شحن ) <span><?php if($order->reference_number != 0): ?> #<?php echo e($order->reference_number); ?> <?php endif; ?></span></span>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_link'); ?>
    طلبات الشراء
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title_link'); ?>
    توصيل دولي (شحن)
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/toastr/toastr.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
    <style>
        /* أنماط CSS لشاشة التحميل */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5); /* خلفية شفافة لشاشة التحميل */
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999; /* يجعل شاشة التحميل فوق جميع العناصر الأخرى */
        }

        .loader {
            border: 4px solid #f3f3f3; /* لون الدائرة الخارجية */
            border-top: 4px solid #3498db; /* لون الدائرة الداخلية */
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 2s linear infinite; /* تأثير دوران */
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
        }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.messge_alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.messge_alert.fail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    
    <?php echo $__env->make('admin.orders.order_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <div class="card-header">
            <h3 class="text-center">توصيل دولي (شحن)</h3>
        </div>

        <div class="card-body">
            <button type="button" class="btn btn-dark mb-2" data-toggle="modal" data-target="#modal-lg-shipping">اضافة
                عرض سعر
            </button>
            <div class="table-responsive">
                <table class="table table-sm table-bordered table-hover">
                    <thead>
                    <tr>
                        <th>شركة الشحن</th>
                        <th>نوع الشحن</th>
                        <th>تم اضافته بواسطة</th>
                        <th>السعر</th>

                        <th>العملة</th>
                        <th>مرفقات</th>
                        <th>الملاحظات</th>
                        <th>العمليات</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if($data->isEmpty()): ?>
                        <tr>
                            <td colspan="7" class="text-center"><span>لا يوجد بيانات</span></td>
                        </tr>
                    <?php else: ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key['shipping']->name); ?></td>
                                <td>
                                    <?php if($key->shipping_type == 1): ?>
                                        <span>بري</span>
                                    <?php elseif($key->shipping_type == 2): ?>
                                        <span>جوي</span>
                                    <?php elseif($key->shipping_type == 3): ?>
                                        <span>بحري</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($key['added_by']->name); ?></td>
                                <td><?php echo e($key->price); ?></td>
                                
                                <td><?php echo e($key['currency']->currency_name); ?></td>
                                <td>
                                    <?php if(empty($key->attachment)): ?>
                                        لا يوجد ملف
                                    <?php else: ?>
                                        <a class="btn btn-primary btn-sm" download="<?php echo e($key->attachment); ?>"
                                           href="<?php echo e(asset('storage/attachment/'.$key->attachment)); ?>"><span class="fa fa-download"></span></a>
                                        <button onclick="viewAttachment('<?php echo e(asset('storage/attachment/'.$key->attachment)); ?>')" href="" class="btn btn-success btn-sm" data-toggle="modal"
                                                data-target="#modal-lg-view_attachment"><span
                                                class="fa fa-search"></span></button>

                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($key->note); ?></td>
                                <td>
                                    <a class="btn btn-success btn-sm"
                                       href="<?php echo e(route('procurement_officer.orders.shipping.edit',['id'=>$key->id])); ?>"><span class="fa fa-search"></span></a>


                                    <?php if($key->award_status == 0): ?>
                                        <button type="button" onclick="getId(<?php echo e($key->id); ?>)" class="btn btn-warning btn-sm"
                                                data-toggle="modal" data-target="#modal-lg-award_shipping">
                                            ترسية
                                        </button>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('procurement_officer.orders.shipping.shipping_award_status_disable',['id'=>$key->id])); ?>"
                                           onclick="return confirm('هل تريد الغاء الترسية ؟')"
                                           class="btn btn-danger btn-sm">الغاء الترسية</a>
                                    <?php endif; ?>
                                    <a class="btn btn-danger btn-sm"
                                       onclick="return confirm('هل تريد الحذف لا يمكن ارجاع الباينات')"
                                       href="<?php echo e(route('procurement_officer.orders.shipping.delete',['id'=>$key->id])); ?>">حذف</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="modal fade" id="modal-lg-shipping">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <form action="<?php echo e(route('procurement_officer.orders.shipping.create')); ?>" method="post"
                          enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($order->id); ?>" name="order_id">
                        <div class="modal-header">
                            <h4 class="modal-title">اضافة ملاحظة</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <?php echo csrf_field(); ?>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="">شركة الشحن</label>
                                        <select required class="form-control select2bs4" name="shipping_company_id" id="">
                                            <option selected value="">اختر شركة الشحن ..</option>
                                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key->id); ?>"><?php echo e($key->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">السعر</label>
                                        <input required type="text" placeholder="يرجى كتابة السعر" name="price"
                                               class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">العملة</label>
                                        <select required class="form-control select2bs4" name="currency_id"
                                                placeholder="يرجى اختيار العملية" id="">
                                            <?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key->id); ?>"><?php echo e($key->currency_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">المرفقات</label>
                                        <input type="file" name="attachment" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="">نوع الشحن</label>
                                        <select class="form-control" name="shipping_type" id="">
                                            <option value="1">بري</option>
                                            <option value="2">جوي</option>
                                            <option value="3">بحري</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="">تصنيف الشحن</label>
                                        <select onchange="selectShippingRating()" class="form-control"
                                                name="shipping_rating" id="shipping_rating">
                                            <option value="1">جزئي</option>
                                            <option value="2">حاوية</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row" id="partial_charge">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">CBM</label>
                                        <input name="cbn" type="text" class="form-control" placeholder="CBM">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">الوزن الاجمالي</label>
                                        <input name="total_weight" type="text" class="form-control"
                                               placeholder="الوزن الاجمالي">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">الوزن الصافي</label>
                                        <input name="net_weight" type="text" class="form-control"
                                               placeholder="الوزن الصافي">
                                    </div>
                                </div>
                            </div>
                            <div class="row" id="container_charge">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">حجم الحاوية</label>
                                        <select class="form-control" name="container_size" id="">
                                            <option value="20">20 قدم</option>
                                            <option value="40">40 قدم</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="">التبريد</label>
                                        <select class="form-control" name="cooling_type" id="">
                                            <option value="1">نعم</option>
                                            <option value="0">لا</option>
                                        </select></div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="">طرق الشحن</label>
                                        <select required class="form-control" name="shipping_method" id="">
                                            <option selected value="">اختر طريقة الشحن ..</option>
                                            <?php $__currentLoopData = $shipping_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key->id); ?>"><?php echo e($key->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <labe>الملاحظات</labe>
                                        <textarea name="note" class="form-control" placeholder="يرجى كتابة الملاحظات"
                                                  id=""
                                                  cols="30" rows="3"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">اغلاق</button>
                            <button type="submit" class="btn btn-primary">حفظ</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="modal fade" id="modal-lg-award_shipping">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <form action="<?php echo e(route('procurement_officer.orders.shipping.create_shipping_award')); ?>"
                          method="post"
                          enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($order->id); ?>" name="order_id">
                        <input type="hidden" id="id" name="id">
                        <div class="modal-header">
                            <h4 class="modal-title">ترسية</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">تاريخ حجز الشحن</label>
                                        <input required name="shipping_reservation_date" type="text"
                                               class="form-control date_format">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">تاريخ الخروج المتوقع</label>
                                        <input name="expected_exit_date" required type="text" class="form-control date_format">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">تاريخ الوصول المتوقع</label>
                                        <input name="expected_arrival_date" required type="text" class="form-control date_format">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">خط الشحن</label>
                                        <input name="shipping_line" type="text" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">بوليصة شحن اولية</label>
                                        <input name="Initial_bill_of_lading" type="file" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">بوليصة شحن فعلية</label>
                                        <input name="actual_bill_of_lading" type="file" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="">ملاحظات</label>
                                        <textarea class="form-control" name="award_notes" id="" cols="30"
                                                  rows="3"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">اغلاق</button>
                            <button type="submit" class="btn btn-primary">حفظ</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>














    </div>
    <?php if(!($shipping_award->isEmpty())): ?>
        <div class="card">
            <div class="card-header">
                <h5 class="text-center">المرسى عليه</h5>
            </div>
            <div class="card-body">
                <?php $__currentLoopData = $shipping_award; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="callout callout-warning">
                        <div class="row">
                            <div class="col-md-6">
                                <h5><?php echo e($key['comapny']->name); ?></h5>
                            </div>
                            <div class="col-md-4" style="font-size: 12px">
                                <label for="">حالة الشحن</label>
                                <?php if(($key->status == 0)): ?>
                                    <span class="alert alert-danger">لا توجد حالة للطلبية</span>
                                <?php elseif($key->status == 1): ?>
                                    <span class="alert alert-info">تحميل من ميناء المورد</span>
                                <?php elseif($key->status == 2): ?>
                                    <span class="alert alert-info">الإبحار في الطريق</span>
                                <?php elseif($key->status == 3): ?>
                                    <span class="alert alert-info">الوصول</span>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-2">
                                <a href="<?php echo e(route('procurement_officer.orders.shipping.edit_shipping_award',['id'=>$key->id])); ?>"
                                   class="btn btn-warning" style="text-decoration: none">تعديل</a>
                            </div>
                        </div>
                    </div>
                    <div class="">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="">تاريخ حجز الشحن</label>
                                    <span class="form-control"><?php echo e($key->shipping_reservation_date); ?></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="">تاريخ الخروج المتوقع</label>
                                    <span class="form-control"><?php echo e($key->expected_exit_date); ?></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="">تاريخ الدخول المتوقع</label>
                                    <span class="form-control"><?php echo e($key->expected_arrival_date); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="">خط الشحن</label>
                                    <span class="form-control"><?php echo e($key->shipping_line); ?></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="">بوليصة شحن اولية</label>
                                    <br>
                                    <?php if(!empty($key->Initial_bill_of_lading)): ?>
                                        <a class="btn btn-primary btn-sm"
                                           href="<?php echo e(asset('storage/attachment/'.$key->Initial_bill_of_lading)); ?>"
                                           download="Initial_bill_of_lading"><span class="fa fa-download"></span></a>
                                        <button onclick="viewAttachment('<?php echo e(asset('storage/attachment/'.$key->Initial_bill_of_lading)); ?>')" href="" class="btn btn-success btn-sm" data-toggle="modal"
                                                data-target="#modal-lg-view_attachment"><span
                                                class="fa fa-search"></span></button>

                                    <?php else: ?>
                                        لا يوجد ملف
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="">بوليصة شحن فعلية</label>
                                    <br>
                                    <?php if(!empty($key->actual_bill_of_lading)): ?>
                                        <a class="btn btn-primary btn-sm"
                                           href="<?php echo e(asset('storage/attachment/'.$key->actual_bill_of_lading)); ?>"
                                           download="actual_bill_of_lading"><span class="fa fa-download"></span></a>
                                        <button onclick="viewAttachment('<?php echo e(asset('storage/attachment/'.$key->actual_bill_of_lading)); ?>')" href="" class="btn btn-success btn-sm" data-toggle="modal"
                                                data-target="#modal-lg-view_attachment"><span
                                                class="fa fa-search"></span></button>
                                    <?php else: ?>
                                        لا يوجد ملف
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php if(!empty($key->award_notes)): ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="">ملاحظات الترسية</label>
                                        <textarea readonly class="form-control" name="award_notes" id="" cols="30"
                                                  rows="3"><?php echo e($key->award_notes); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
<div class="text-center">
    <p>تم انشاء هذه الطلبية بواسطة <span class="text-danger text-bold"><?php echo e($order['user']->name ?? ''); ?></span> ويتم متابعتها بواسطة <span class="text-danger text-bold"><?php echo e($order['to_user']->name ?? ''); ?></span></p>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/jszip/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/pdfmake/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/pdfmake/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.colVis.min.js')); ?>"></script>


    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.full.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/toastr/toastr.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/dist/js/demo.js')); ?>"></script>

    <script>
        function getId(id) {
            document.getElementById('id').value = id;
        }
    </script>

    <script>
        $('#container_charge').hide();
        $('#partial_charge').show();

        function selectShippingRating() {
            var shipping_rating = document.getElementById('shipping_rating');
            if (shipping_rating.value == 1) {
                $('#partial_charge').show();
                $('#container_charge').hide();
            } else if (shipping_rating.value == 2) {
                $('#container_charge').show();
                $('#partial_charge').hide();
            }
        }
    </script>

    <script>
        function updateStatus(id) {
            var csrfToken = $('meta[name="csrf-token"]').attr('content');
            var headers = {
                "X-CSRF-Token": csrfToken
            };
            $.ajax({
                url: '<?php echo e(url('users/updateStatus')); ?>',
                method: 'post',
                headers: headers,
                data: {
                    'id': id,
                    'user_status': document.getElementById('customSwitch' + id).checked
                },
                success: function (data) {
                    toastr.success('تم تعديل الحالة بنجاح')
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert('error');
                }
            });
        }

        $(document).ready(function () {
            showLoader();
            getOrderTable();
        });

        function getOrderTable() {
            var csrfToken = $('meta[name="csrf-token"]').attr('content');
            $.ajaxSetup({headers: {'X-CSRF-TOKEN': csrfToken}});

            $.ajax({
                url: '<?php echo e(url('users/procurement_officer/orders/order_table')); ?>',
                method: 'post',
                data: {
                    'search_order_number': document.getElementById('search_order_number').value
                },
                success: function (data) {
                    $('#order_table').html(data);
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert(errorThrown);
                },
                complete: function () {
                    // إخفاء شاشة التحميل بعد انتهاء استدعاء البيانات
                    hideLoader();
                }
            });
        }

        function showLoader() {
            $('#loaderContainer').show();
        }

        // دالة لإخفاء شاشة التحميل
        function hideLoader() {
            $('#loaderContainer').hide();
        }

        function myFunction() {
            alert('load');
        }

        // window.onload = getOrderTable();
    </script>

    <script>
        $(function () {
            $("#example1").DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                // "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        });
    </script>

    <script>
        $(function () {
            var Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000
            });

            $('.swalDefaultSuccess').click(function () {
                Toast.fire({
                    icon: 'success',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.swalDefaultInfo').click(function () {
                Toast.fire({
                    icon: 'info',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.swalDefaultError').click(function () {
                Toast.fire({
                    icon: 'error',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.swalDefaultWarning').click(function () {
                Toast.fire({
                    icon: 'warning',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.swalDefaultQuestion').click(function () {
                Toast.fire({
                    icon: 'question',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });

            $('.toastrDefaultSuccess').click(function () {
                toastr.success('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
            });
            $('.toastrDefaultInfo').click(function () {
                toastr.info('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
            });
            $('.toastrDefaultError').click(function () {
                toastr.error('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
            });
            $('.toastrDefaultWarning').click(function () {
                toastr.warning('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
            });

            $('.toastsDefaultDefault').click(function () {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultTopLeft').click(function () {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    position: 'topLeft',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultBottomRight').click(function () {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    position: 'bottomRight',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultBottomLeft').click(function () {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    position: 'bottomLeft',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultAutohide').click(function () {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    autohide: true,
                    delay: 750,
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultNotFixed').click(function () {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    fixed: false,
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultFull').click(function () {
                $(document).Toasts('create', {
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    icon: 'fas fa-envelope fa-lg',
                })
            });
            $('.toastsDefaultFullImage').click(function () {
                $(document).Toasts('create', {
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    image: '../../dist/img/user3-128x128.jpg',
                    imageAlt: 'User Picture',
                })
            });
            $('.toastsDefaultSuccess').click(function () {
                $(document).Toasts('create', {
                    class: 'bg-success',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultInfo').click(function () {
                $(document).Toasts('create', {
                    class: 'bg-info',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultWarning').click(function () {
                $(document).Toasts('create', {
                    class: 'bg-warning',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultDanger').click(function () {
                $(document).Toasts('create', {
                    class: 'bg-danger',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultMaroon').click(function () {
                $(document).Toasts('create', {
                    class: 'bg-maroon',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
        });

    </script>

    <script>
        $(function () {
            //Initialize Select2 Elements
            $('.select2').select2()

            //Initialize Select2 Elements
            $('.select2bs4').select2({
                theme: 'bootstrap4'
            })
        })
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/orders/procurement_officer/shipping/index.blade.php ENDPATH**/ ?>