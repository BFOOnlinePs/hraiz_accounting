<table class="table table-bordered table-hover mt-2">
    <tr>
        <th>اسم الموظف</th>
        <th>الحالة</th>
        <th>تاريخ الاضافة</th>
        <th>تاريخ التسليم</th>
        <th>ملاحظات</th>
        <th>العمليات</th>
    </tr>
    <?php if($data->isEmpty()): ?>
        <tr>
            <td colspan="6" class="text-center">لا توجد بيانات</td>
        </tr>
    <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key->user->name); ?></td>
                <td>
                    <select class="form-control" onchange="update_production_order_status(<?php echo e($key->id); ?>,this.value)" name="status" id="">
                        <option <?php if($key->status == 'new'): ?> selected <?php endif; ?> value="new">جديد</option>
                        <option <?php if($key->status == 'process'): ?> selected <?php endif; ?> value="process">قيد التنفيذ</option>
                        <option <?php if($key->status == 'complete'): ?> selected <?php endif; ?> value="complete">مكتمل</option>
                    </select>
                </td>
                <td><?php echo e($key->insert_at); ?></td>
                <td><?php echo e($key->submission_date); ?></td>
                <td><?php echo e($key->notes); ?></td>
                <td>
                    <a href="<?php echo e(route('production.production_inputs.edit_production_orders',['id'=>$key->id])); ?>" class="btn btn-success btn-sm"><span class="fa fa-edit"></span></a>
                    <a onclick="return confirm('هل انت متاكد من عملية الحذف ؟')" href="<?php echo e(route('production.production_inputs.delete_production_orders',['id'=>$key->id])); ?>" class="btn btn-danger btn-sm"><span class="fa fa-trash"></span></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</table>
<?php echo e($data->links()); ?>

<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/production/production_line/ajax/production_order_table.blade.php ENDPATH**/ ?>