<div class="modal fade" id="list_invoice_clients_modal">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <input type="hidden" name="">
        <div class="modal-content">
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <input type="text" id="input_search_clients" class="form-control input_serach" placeholder="بحث حسب زبون او مورد">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <input type="text" id="input_search_reference_number" class="form-control input_serach" placeholder="بحث حسب الرقم المرجعي للفاتورة">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <div id="list_invoice_users">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/bonds/performance_bond/modals/list_invoice_clients.blade.php ENDPATH**/ ?>