<div class="modal fade" id="list_invoice_type">
    <div class="modal-dialog modal-dialog-centered">
        <input type="hidden" name="">
        <div class="modal-content">
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12 d-flex justify-content-around">
                        <button class="btn btn-dark" onclick="list_invoice_clients_modal()">من فاتورة</button>
                        <button class="btn btn-dark" onclick="view_create_payment_bond_for_client_modal()">مباشرة</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/accounting/bonds/payment_bond/modals/list_invoice_type.blade.php ENDPATH**/ ?>