<table class="table table-sm table-hover table-bordered">
    <thead>
    <tr>
        <th>اسم الصنف</th>
        <th></th>
    </tr>
    </thead>
    <tbody>
    <?php if($data->isEmpty()): ?>
        <tr>
            <td colspan="2" class="text-center">لا توجد اصناف</td>
        </tr>
    <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($key->production_input_name); ?>

                </td>
                <td>
                    <button onclick="delete_production_input_ajax(<?php echo e($key->id); ?>)" class="btn btn-danger btn-sm"><span class="fa fa-close"></span></button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </tbody>
</table>
<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/production/production_line/ajax/production_line_input_table.blade.php ENDPATH**/ ?>