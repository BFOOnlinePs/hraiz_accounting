<?php $__env->startSection('title'); ?>
    المخازن
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title'); ?>
    المخازن
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_link'); ?>
    الرئيسية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title_link'); ?>
    المخازن
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/toastr/toastr.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.messge_alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.messge_alert.fail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">

                
                
                

                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <button class="btn btn-dark" data-toggle="modal" data-target="#wherehouseCreateModal">اضافة مخزن</button>
                            <div class="row mt-2">
                                <div class="col-md-12">
                                    <table class="table table-sm table-bordered">
                                        <thead>
                                            <tr>
                                                <th>اسم المخزن</th>
                                                <th>العنوان</th>
                                                <th>رقم الهاتف</th>
                                                <th>نوع المخزن</th>
                                                <th>المسؤول عن المخزن</th>
                                                <th>العمليات</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php if($data->isEmpty()): ?>
                                            <tr>
                                                <td colspan="6" class="text-center">لا يوجد بيانات</td>
                                            </tr>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($key->wherehouse_name); ?></td>
                                                    <td><?php echo e($key->wherehouse_address); ?></td>
                                                    <td><?php echo e($key->wherehouse_phone); ?></td>
                                                    <td><?php echo e($key->wherehouse_type); ?></td>
                                                    <td><?php echo e($key->user->name); ?></td>
                                                    <td>
                                                        <button onclick="wherehouse_edit_modal_open(<?php echo e($key); ?>)" class="btn btn-success btn-sm"><span class="fa fa-edit"></span></button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.wherehouse.modals.wherehouseCreateModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.wherehouse.modals.wherehouseEditModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.full.min.js')); ?>"></script>
    <script>
        function wherehouse_edit_modal_open(data) {
            $('#wherehouse_id').val(data.id);
            $('#wherehouse_name').val(data.wherehouse_name);
            $('#wherehouse_phone').val(data.wherehouse_phone);
            $('#wherehouse_address').val(data.wherehouse_address);
            $('#wherehouse_type').val(data.wherehouse_type);
            var newValue = data.wherehouse_store_manager;
            $('#wherehouse_store_manager').val(data.wherehouse_store_manager).trigger('change');
            $('#wherehouseEditModal').modal('show');
        }
    </script>
    <script>
        $(function (){
            $('.select2bs4').select2({
                theme: 'bootstrap4'
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/wherehouse/index.blade.php ENDPATH**/ ?>