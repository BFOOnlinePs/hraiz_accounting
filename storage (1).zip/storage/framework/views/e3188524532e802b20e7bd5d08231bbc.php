<?php $__env->startSection('title'); ?>
    المستخدمين
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title'); ?>
    المستخدمين
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_link'); ?>
    الرئيسية
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_title_link'); ?>
    المستخدمين
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 mb-3">
            <a href="<?php echo e(route('users.add_form')); ?>" class="btn btn-dark">اضافة مستخدم جديد</a>
        </div>
        <div class="col-md-3 col-sm-6 col-12">
            <a href="<?php echo e(route('users.procurement_officer.index')); ?>" style="text-decoration: none" class="text-dark">
                <div class="info-box shadow-sm">
                    <span class="info-box-icon bg-info"><i class="far fa-envelope"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">موظف المشتريات</span>

                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-3 col-sm-6 col-12">
            <a href="<?php echo e(route('users.storekeeper.index')); ?>" style="text-decoration: none" class="text-dark">
                <div class="info-box shadow-sm">
                    <span class="info-box-icon bg-success"><i class="far fa-flag"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">أمين المستودع</span>

                    </div>

                </div>
            </a>
        </div>
        <div class="col-md-3 col-sm-6 col-12">
            <a href="<?php echo e(route('users.secretarial.index')); ?>" style="text-decoration: none" class="text-dark">
                <div class="info-box shadow-sm">
                    <span class="info-box-icon bg-warning"><i class="far fa-copy"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">سكرتيريا</span>

                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-3 col-sm-6 col-12">
            <a href="<?php echo e(route('users.supplier.index')); ?>" style="text-decoration: none" class="text-dark">
                <div class="info-box shadow-sm">
                    <span class="info-box-icon bg-danger"><i class="far fa-star"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">الموردين</span>

                    </div>
                </div>

            </a>
        </div>
        <div class="col-md-3 col-sm-6 col-12">
            <a href="<?php echo e(route('users.delivery_company.index')); ?>" style="text-decoration: none" class="text-dark">
                <div class="info-box shadow-sm">
                    <span class="info-box-icon bg-info"><i class="far fa-envelope"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">شركات الشحن</span>

                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-3 col-sm-6 col-12">
            <a href="<?php echo e(route('users.clearance_companies.index')); ?>" style="text-decoration: none" class="text-dark">
                <div class="info-box shadow-sm">
                    <span class="info-box-icon bg-info"><i class="far fa-envelope"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">شركات التخليص</span>

                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-3 col-sm-6 col-12">
            <a href="<?php echo e(route('users.local_carriers.index')); ?>" style="text-decoration: none" class="text-dark">
                <div class="info-box shadow-sm">
                    <span class="info-box-icon bg-info"><i class="far fa-envelope"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">شركات النقل المحلي</span>

                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-3 col-sm-6 col-12">
            <a href="<?php echo e(route('users.insurance_companies.index')); ?>" style="text-decoration: none" class="text-dark">
                <div class="info-box shadow-sm">
                    <span class="info-box-icon bg-info"><i class="far fa-envelope"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">شركات التأمين</span>

                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-3 col-sm-6 col-12">
            <a href="<?php echo e(route('users.clients.index')); ?>" style="text-decoration: none" class="text-dark">
                <div class="info-box shadow-sm">
                    <span class="info-box-icon bg-info"><i class="far fa-envelope"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">زبائن</span>

                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-3 col-sm-6 col-12">
            <a href="<?php echo e(route('users.employees.index')); ?>" style="text-decoration: none" class="text-dark">
                <div class="info-box shadow-sm">
                    <span class="info-box-icon bg-info"><i class="far fa-envelope"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">الموظفين</span>

                    </div>
                </div>
            </a>
        </div>
        
        
        
        
        
        
        
        
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/users/index.blade.php ENDPATH**/ ?>