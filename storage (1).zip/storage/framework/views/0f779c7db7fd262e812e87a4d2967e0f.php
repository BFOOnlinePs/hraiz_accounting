<table class="table table-bordered">
    <thead>
        <tr>
            <th class="sorting sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-sort="ascending">#
            </th>
            <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1">التاريخ</th>
            <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1">نوع الإجازة</th>
            <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1">الملف المرفق</th>
            <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1">العمليات</th>
        </tr>
    </thead>
    <tbody>
        <?php if($vacations->isEmpty()): ?>
            <tr>
                <td colspan="5" class="text-center">لا توجد نتائج</td>
            </tr>
        <?php endif; ?>
        <?php $__currentLoopData = $vacations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->index + 1); ?></td>
            <td><?php echo e($key->v_date); ?></td>
            <td><?php echo e($key->name->type_name); ?></td>
            <td>
                <a target="_blank" href="<?php echo e(asset('storage/vacations/'.$key->attachement)); ?>" download="attachment">تحميل الملف</a>
            </td>
            <td>
                <button class="btn btn-success btn-sm" onclick="edit_vacation(<?php echo e($key->id); ?> , '<?php echo e($key->v_date); ?>' , '<?php echo e($key->name->type_name); ?>' , <?php echo e($key->vacations_type_id); ?> , '<?php echo e($key->notes); ?>' , '<?php echo e($key->attachement); ?>')"><span class="fa fa-edit pt-1"></span></button>
            </td>
            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($vacations->links()); ?>

<?php /**PATH /home/u805989271/domains/360alum.com/public_html/app/resources/views/admin/hr/employees/ajax/vacations_table.blade.php ENDPATH**/ ?>